"""
Document History and Tier Management Module

This module handles document history tracking, subscription tier management,
and secure document storage for the .fylr tax filing application.
"""

import os
import json
import logging
import uuid
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, session, send_file
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.models import User, TaxForm, TaxStrategy, DocumentHistory, SubscriptionTier, DocumentAccess
from app import db
from app.access_control import requires_access_level, unlock_tool
import hashlib
import hmac
import base64

# Create blueprint
tier_management_bp = Blueprint("tier_management", __name__, url_prefix="/tier-management")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define document storage path
DOCUMENT_STORAGE_PATH = os.path.join(os.getcwd(), 'secure_documents')
os.makedirs(DOCUMENT_STORAGE_PATH, exist_ok=True)

# Define subscription tiers
SUBSCRIPTION_TIERS = {
    "free": {
        "name": ".fylr Basic",
        "price": 0,
        "features": [
            "guided_input",
            "auto_fill",
            "form_generation",
            "pdf_export",
            "educational_guidance"
        ],
        "description": "Essential features for basic tax filing"
    },
    "premium": {
        "name": ".fylr+",
        "price": 47,
        "features": [
            "guided_input",
            "auto_fill",
            "form_generation",
            "pdf_export",
            "educational_guidance",
            "save_progress",
            "smart_form_logic",
            "enhanced_ai_support",
            "dynamic_checklist",
            "export_forms"
        ],
        "description": "Advanced features with AI-powered guidance"
    },
    "pro": {
        "name": ".fylr Pro",
        "price": 97,
        "features": [
            "guided_input",
            "auto_fill",
            "form_generation",
            "pdf_export",
            "educational_guidance",
            "save_progress",
            "smart_form_logic",
            "enhanced_ai_support",
            "dynamic_checklist",
            "export_forms",
            "ai_deduction_detection",
            "ai_sorted_uploads",
            "filing_export_support",
            "audit_protection",
            "priority_support"
        ],
        "description": "Premium features with audit protection and priority support"
    }
}

def generate_document_key():
    """Generate a secure random key for document encryption"""
    return base64.b64encode(os.urandom(32)).decode('utf-8')

def encrypt_document_id(document_id):
    """Create a secure token for document access"""
    secret_key = os.environ.get('DOCUMENT_SECRET_KEY', 'development_key')
    message = str(document_id).encode('utf-8')
    signature = hmac.new(secret_key.encode('utf-8'), message, hashlib.sha256).hexdigest()
    return f"{document_id}:{signature}"

def verify_document_token(token):
    """Verify a document access token"""
    try:
        document_id, signature = token.split(':')
        expected_token = encrypt_document_id(document_id)
        if expected_token == token:
            return int(document_id)
        return None
    except:
        return None

@tier_management_bp.route("/subscription-management")
@login_required
def subscription_management():
    """Subscription management dashboard"""
    # Get user's current subscription
    user_tier = current_user.plan.value if hasattr(current_user.plan, 'value') else 'free'
    
    # Get available tiers
    tiers = SUBSCRIPTION_TIERS
    
    # Get user's feature access
    user_features = []
    for tier_name, tier_data in tiers.items():
        if tier_name == user_tier or tier_name == 'free':
            user_features.extend(tier_data['features'])
    
    return render_template(
        "tier_management/subscription_management.html",
        current_tier=user_tier,
        tiers=tiers,
        user_features=user_features
    )

@tier_management_bp.route("/upgrade-subscription/<tier>")
@login_required
def upgrade_subscription(tier):
    """Upgrade subscription tier"""
    if tier not in SUBSCRIPTION_TIERS:
        flash("Invalid subscription tier", "danger")
        return redirect(url_for("tier_management.subscription_management"))
    
    # Redirect to billing page for payment
    return redirect(url_for("billing.create_checkout_session", product_id=tier))

@tier_management_bp.route("/document-history")
@login_required
@requires_access_level("save_progress")
def document_history():
    """View document history"""
    # Get user's document history
    history = DocumentHistory.query.filter_by(user_id=current_user.id).order_by(DocumentHistory.created_at.desc()).all()
    
    return render_template(
        "tier_management/document_history.html",
        history=history
    )

@tier_management_bp.route("/document-access/<token>")
@login_required
def document_access(token):
    """Access a document via secure token"""
    # Verify token
    document_id = verify_document_token(token)
    if not document_id:
        flash("Invalid or expired document access token", "danger")
        return redirect(url_for("main.dashboard"))
    
    # Get document
    document = DocumentAccess.query.get(document_id)
    if not document:
        flash("Document not found", "danger")
        return redirect(url_for("main.dashboard"))
    
    # Check if user has access
    if document.user_id != current_user.id:
        flash("You do not have access to this document", "danger")
        return redirect(url_for("main.dashboard"))
    
    # Check if document exists
    document_path = os.path.join(DOCUMENT_STORAGE_PATH, document.filename)
    if not os.path.exists(document_path):
        flash("Document file not found", "danger")
        return redirect(url_for("main.dashboard"))
    
    # Log access
    history_entry = DocumentHistory(
        user_id=current_user.id,
        document_id=document.id,
        action="access",
        details=f"Accessed document: {document.document_name}"
    )
    db.session.add(history_entry)
    db.session.commit()
    
    # Serve document
    return send_file(document_path, as_attachment=True, download_name=document.document_name)

@tier_management_bp.route("/save-document", methods=["POST"])
@login_required
@requires_access_level("save_progress")
def save_document():
    """Save a document to secure storage"""
    try:
        # Check if file was uploaded
        if 'file' not in request.files:
            return jsonify({"success": False, "message": "No file selected"}), 400
        
        file = request.files['file']
        
        # Check if file was selected
        if file.filename == '':
            return jsonify({"success": False, "message": "No file selected"}), 400
        
        # Get document metadata
        document_name = request.form.get('document_name', file.filename)
        document_type = request.form.get('document_type', 'other')
        
        # Secure the filename
        filename = secure_filename(str(uuid.uuid4()) + '_' + file.filename)
        
        # Save the file
        file_path = os.path.join(DOCUMENT_STORAGE_PATH, filename)
        file.save(file_path)
        
        # Create document access record
        document = DocumentAccess(
            user_id=current_user.id,
            document_name=document_name,
            document_type=document_type,
            filename=filename,
            file_size=os.path.getsize(file_path),
            content_type=file.content_type
        )
        db.session.add(document)
        db.session.commit()
        
        # Log document save
        history_entry = DocumentHistory(
            user_id=current_user.id,
            document_id=document.id,
            action="save",
            details=f"Saved document: {document_name}"
        )
        db.session.add(history_entry)
        db.session.commit()
        
        # Generate access token
        access_token = encrypt_document_id(document.id)
        
        return jsonify({
            "success": True,
            "message": "Document saved successfully",
            "document_id": document.id,
            "access_token": access_token
        })
    
    except Exception as e:
        logger.error(f"Error saving document: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@tier_management_bp.route("/delete-document/<int:document_id>", methods=["POST"])
@login_required
@requires_access_level("save_progress")
def delete_document(document_id):
    """Delete a document from secure storage"""
    try:
        # Get document
        document = DocumentAccess.query.get(document_id)
        if not document:
            return jsonify({"success": False, "message": "Document not found"}), 404
        
        # Check if user has access
        if document.user_id != current_user.id:
            return jsonify({"success": False, "message": "You do not have access to this document"}), 403
        
        # Delete file
        document_path = os.path.join(DOCUMENT_STORAGE_PATH, document.filename)
        if os.path.exists(document_path):
            os.remove(document_path)
        
        # Log document deletion
        history_entry = DocumentHistory(
            user_id=current_user.id,
            document_id=document.id,
            action="delete",
            details=f"Deleted document: {document.document_name}"
        )
        db.session.add(history_entry)
        
        # Delete document record
        db.session.delete(document)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Document deleted successfully"
        })
    
    except Exception as e:
        logger.error(f"Error deleting document: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@tier_management_bp.route("/feature-access/<feature>")
@login_required
def feature_access(feature):
    """Check if user has access to a feature"""
    # Get access information
    access_info = unlock_tool(current_user, feature)
    
    return jsonify(access_info)

@tier_management_bp.route("/document-activity-log")
@login_required
@requires_access_level("enhanced_audit_protection")
def document_activity_log():
    """View detailed document activity log"""
    # Get user's document history with pagination
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    history = DocumentHistory.query.filter_by(user_id=current_user.id).order_by(
        DocumentHistory.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    return render_template(
        "tier_management/document_activity_log.html",
        history=history
    )

@tier_management_bp.route("/export-document-history")
@login_required
@requires_access_level("enhanced_audit_protection")
def export_document_history():
    """Export document history to CSV"""
    try:
        # Get user's document history
        history = DocumentHistory.query.filter_by(user_id=current_user.id).order_by(
            DocumentHistory.created_at.desc()
        ).all()
        
        # Create CSV content
        csv_content = "Date,Document,Action,Details\n"
        for entry in history:
            # Format date
            date_str = entry.created_at.strftime("%Y-%m-%d %H:%M:%S")
            
            # Get document name
            document_name = "Unknown"
            if entry.document_id:
                document = DocumentAccess.query.get(entry.document_id)
                if document:
                    document_name = document.document_name
            
            # Add row
            csv_content += f'"{date_str}","{document_name}","{entry.action}","{entry.details}"\n'
        
        # Create temporary file
        temp_file = os.path.join(os.getcwd(), 'temp', f'document_history_{current_user.id}.csv')
        os.makedirs(os.path.dirname(temp_file), exist_ok=True)
        
        with open(temp_file, 'w') as f:
            f.write(csv_content)
        
        # Log export
        history_entry = DocumentHistory(
            user_id=current_user.id,
            action="export",
            details="Exported document history"
        )
        db.session.add(history_entry)
        db.session.commit()
        
        # Serve file
        return send_file(temp_file, as_attachment=True, download_name="document_history.csv")
    
    except Exception as e:
        logger.error(f"Error exporting document history: {str(e)}")
        flash(f"An error occurred: {str(e)}", "danger")
        return redirect(url_for("tier_management.document_activity_log"))

@tier_management_bp.route("/audit-protection-dashboard")
@login_required
@requires_access_level("audit_protection")
def audit_protection_dashboard():
    """Audit protection dashboard"""
    # Get user's business profile
    from app.models import BusinessProfile
    profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get user's document count
    document_count = DocumentAccess.query.filter_by(user_id=current_user.id).count()
    
    # Get user's form count
    form_count = TaxForm.query.filter_by(user_id=current_user.id).count()
    
    # Get user's strategy count
    strategy_count = TaxStrategy.query.filter_by(user_id=current_user.id).count()
    
    # Calculate audit risk score (simplified example)
    audit_risk_score = 0
    risk_factors = []
    
    if profile:
        # Base risk by business type
        business_type_risk = {
            "sole_proprietor": 3,
            "llc": 2,
            "s_corp": 2,
            "c_corp": 1
        }
        
        business_type = profile.business_type
        if hasattr(business_type, 'value'):
            business_type = business_type.value
            
        if business_type in business_type_risk:
            audit_risk_score += business_type_risk[business_type]
        
        # Revenue risk
        if profile.annual_revenue > 200000:
            audit_risk_score += 3
            risk_factors.append("High annual revenue")
        elif profile.annual_revenue > 100000:
            audit_risk_score += 2
            risk_factors.append("Moderate annual revenue")
        
        # Home office deduction
        if profile.has_home_office:
            audit_risk_score += 1
            risk_factors.append("Home office deduction")
        
        # Vehicle deduction
        if profile.has_vehicle:
            audit_risk_score += 1
            risk_factors.append("Vehicle deduction")
        
        # Employee risk
        if profile.has_employees and profile.employee_count > 10:
            audit_risk_score += 2
            risk_factors.append("Multiple employees")
        
        # Documentation risk
        if document_count < 5:
            audit_risk_score += 2
            risk_factors.append("Limited documentation")
    
    # Cap risk score at 10
    audit_risk_score = min(audit_risk_score, 10)
    
    # Determine risk level
    risk_level = "Low"
    if audit_risk_score >= 7:
        risk_level = "High"
    elif audit_risk_score >= 4:
        risk_level = "Medium"
    
    # Get audit protection recommendations
    recommendations = [
        "Maintain organized records of all business expenses",
        "Keep business and personal finances separate",
        "Document all business-related travel and meals",
        "Retain receipts for all business purchases"
    ]
    
    # Add business-type specific recommendations
    if profile:
        business_type = profile.business_type
        if hasattr(business_type, 'value'):
            business_type = business_type.value
            
        if business_type == "sole_proprietor":
            recommendations.append("Document hours worked in home office")
            recommendations.append("Track business vs. personal use of vehicle")
        elif business_type == "s_corp":
            recommendations.append("Ensure reasonable compensation for shareholder-employees")
            recommendations.append("Document all shareholder distributions")
        elif business_type == "c_corp":
            recommendations.append("Document all board meeting minutes")
            recommendations.append("Maintain clear records of all corporate expenses")
    
    return render_template(
        "tier_management/audit_protection_dashboard.html",
        profile=profile,
        document_count=document_count,
        form_count=form_count,
        strategy_count=strategy_count,
        audit_risk_score=audit_risk_score,
        risk_level=risk_level,
        risk_factors=risk_factors,
        recommendations=recommendations
    )

@tier_management_bp.route("/document-checklist")
@login_required
@requires_access_level("audit_protection")
def document_checklist():
    """Document checklist for audit protection"""
    # Get user's business profile
    from app.models import BusinessProfile
    profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not profile:
        flash("Please complete your business profile first", "warning")
        return redirect(url_for("automation.business_profile_wizard"))
    
    # Get business type
    business_type = profile.business_type
    if hasattr(business_type, 'value'):
        business_type = business_type.value
    
    # Define document checklist based on business type
    checklist = {
        "income_documents": [
            {"name": "Bank statements", "description": "Monthly statements for all business accounts", "required": True},
            {"name": "Payment processor statements", "description": "Statements from PayPal, Stripe, Square, etc.", "required": True},
            {"name": "Sales receipts", "description": "Copies of all sales receipts", "required": True},
            {"name": "Invoices", "description": "Copies of all invoices sent to customers", "required": True}
        ],
        "expense_documents": [
            {"name": "Receipts", "description": "Receipts for all business expenses", "required": True},
            {"name": "Credit card statements", "description": "Statements for business credit cards", "required": True},
            {"name": "Vendor invoices", "description": "Invoices from all vendors and suppliers", "required": True},
            {"name": "Rent receipts", "description": "Receipts for office or retail space rent", "required": profile.business_address is not None}
        ],
        "asset_documents": [
            {"name": "Equipment purchases", "description": "Receipts for equipment and furniture", "required": profile.has_equipment_purchases},
            {"name": "Vehicle records", "description": "Purchase documents and mileage logs", "required": profile.has_vehicle},
            {"name": "Depreciation records", "description": "Records of depreciation for business assets", "required": profile.has_equipment_purchases}
        ]
    }
    
    # Add business-type specific documents
    if business_type == "sole_proprietor":
        checklist["tax_documents"] = [
            {"name": "Schedule C", "description": "Copy of filed Schedule C", "required": True},
            {"name": "Schedule SE", "description": "Copy of filed Schedule SE", "required": True},
            {"name": "Form 1040", "description": "Copy of filed Form 1040", "required": True},
            {"name": "Estimated tax payments", "description": "Records of quarterly estimated tax payments", "required": True}
        ]
    elif business_type == "llc":
        if profile.employee_count == 0 and getattr(profile, 'contractor_count', 0) == 0:
            # Single-member LLC
            checklist["tax_documents"] = [
                {"name": "Schedule C", "description": "Copy of filed Schedule C", "required": True},
                {"name": "Schedule SE", "description": "Copy of filed Schedule SE", "required": True},
                {"name": "Form 1040", "description": "Copy of filed Form 1040", "required": True},
                {"name": "Estimated tax payments", "description": "Records of quarterly estimated tax payments", "required": True}
            ]
        else:
            # Multi-member LLC
            checklist["tax_documents"] = [
                {"name": "Form 1065", "description": "Copy of filed Form 1065", "required": True},
                {"name": "Schedule K-1", "description": "Copies of all Schedule K-1s", "required": True},
                {"name": "Partnership agreement", "description": "Copy of partnership agreement", "required": True},
                {"name": "Estimated tax payments", "description": "Records of quarterly estimated tax payments", "required": True}
            ]
    elif business_type == "s_corp":
        checklist["tax_documents"] = [
            {"name": "Form 1120-S", "description": "Copy of filed Form 1120-S", "required": True},
            {"name": "Schedule K-1", "description": "Copies of all Schedule K-1s", "required": True},
            {"name": "Form 941", "description": "Quarterly employment tax returns", "required": profile.has_employees},
            {"name": "Form W-2", "description": "Copies of all W-2s issued", "required": profile.has_employees},
            {"name": "Form 1099", "description": "Copies of all 1099s issued", "required": getattr(profile, 'contractor_count', 0) > 0},
            {"name": "Corporate bylaws", "description": "Copy of corporate bylaws", "required": True},
            {"name": "Corporate minutes", "description": "Minutes of corporate meetings", "required": True}
        ]
    elif business_type == "c_corp":
        checklist["tax_documents"] = [
            {"name": "Form 1120", "description": "Copy of filed Form 1120", "required": True},
            {"name": "Form 941", "description": "Quarterly employment tax returns", "required": profile.has_employees},
            {"name": "Form W-2", "description": "Copies of all W-2s issued", "required": profile.has_employees},
            {"name": "Form 1099", "description": "Copies of all 1099s issued", "required": getattr(profile, 'contractor_count', 0) > 0},
            {"name": "Corporate bylaws", "description": "Copy of corporate bylaws", "required": True},
            {"name": "Corporate minutes", "description": "Minutes of corporate meetings", "required": True},
            {"name": "Dividend records", "description": "Records of all dividends paid", "required": True}
        ]
    
    # Add employee-specific documents
    if profile.has_employees:
        checklist["employee_documents"] = [
            {"name": "Payroll records", "description": "Complete payroll records for all employees", "required": True},
            {"name": "Form W-4", "description": "W-4 forms for all employees", "required": True},
            {"name": "Employment agreements", "description": "Contracts for all employees", "required": True},
            {"name": "Benefits documentation", "description": "Records of all employee benefits", "required": True}
        ]
    
    # Add contractor-specific documents
    if getattr(profile, 'contractor_count', 0) > 0:
        checklist["contractor_documents"] = [
            {"name": "Form W-9", "description": "W-9 forms for all contractors", "required": True},
            {"name": "Form 1099-NEC", "description": "Copies of all 1099-NECs issued", "required": True},
            {"name": "Contractor agreements", "description": "Contracts for all contractors", "required": True},
            {"name": "Contractor invoices", "description": "Invoices from all contractors", "required": True}
        ]
    
    # Get user's uploaded documents
    user_documents = DocumentAccess.query.filter_by(user_id=current_user.id).all()
    
    # Create a map of document types to count
    document_counts = {}
    for document in user_documents:
        if document.document_type in document_counts:
            document_counts[document.document_type] += 1
        else:
            document_counts[document.document_type] = 1
    
    return render_template(
        "tier_management/document_checklist.html",
        profile=profile,
        checklist=checklist,
        document_counts=document_counts,
        user_documents=user_documents
    )

@tier_management_bp.route("/update-document-type/<int:document_id>", methods=["POST"])
@login_required
@requires_access_level("audit_protection")
def update_document_type(document_id):
    """Update document type for audit protection"""
    try:
        # Get document
        document = DocumentAccess.query.get(document_id)
        if not document:
            return jsonify({"success": False, "message": "Document not found"}), 404
        
        # Check if user has access
        if document.user_id != current_user.id:
            return jsonify({"success": False, "message": "You do not have access to this document"}), 403
        
        # Update document type
        document_type = request.json.get('document_type')
        if not document_type:
            return jsonify({"success": False, "message": "Document type is required"}), 400
        
        document.document_type = document_type
        
        # Log update
        history_entry = DocumentHistory(
            user_id=current_user.id,
            document_id=document.id,
            action="update",
            details=f"Updated document type to: {document_type}"
        )
        db.session.add(history_entry)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Document type updated successfully"
        })
    
    except Exception as e:
        logger.error(f"Error updating document type: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500
