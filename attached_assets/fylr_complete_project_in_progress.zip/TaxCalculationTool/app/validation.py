"""
Validation and Testing Module

This module provides comprehensive testing and validation functionality
for the .fylr tax filing application.
"""

import os
import json
import logging
import requests
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_required, current_user
from app.models import User, BusinessProfile, TaxForm, TaxStrategy, DocumentHistory, DocumentAccess
from app import db
from app.access_control import requires_access_level
import time
from datetime import datetime

# Create blueprint
validation_bp = Blueprint("validation", __name__, url_prefix="/validation")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@validation_bp.route("/test-dashboard")
@login_required
@requires_access_level("admin")
def test_dashboard():
    """Admin test dashboard for system validation"""
    return render_template("validation/test_dashboard.html")

@validation_bp.route("/run-validation-tests", methods=["POST"])
@login_required
@requires_access_level("admin")
def run_validation_tests():
    """Run automated validation tests"""
    try:
        # Get test type from request
        test_type = request.json.get("test_type", "all")
        
        # Initialize results
        results = {
            "success": True,
            "tests_run": 0,
            "tests_passed": 0,
            "tests_failed": 0,
            "test_results": []
        }
        
        # Run user flow tests
        if test_type == "all" or test_type == "user_flows":
            user_flow_results = run_user_flow_tests()
            results["tests_run"] += user_flow_results["tests_run"]
            results["tests_passed"] += user_flow_results["tests_passed"]
            results["tests_failed"] += user_flow_results["tests_failed"]
            results["test_results"].extend(user_flow_results["test_results"])
        
        # Run form generation tests
        if test_type == "all" or test_type == "form_generation":
            form_generation_results = run_form_generation_tests()
            results["tests_run"] += form_generation_results["tests_run"]
            results["tests_passed"] += form_generation_results["tests_passed"]
            results["tests_failed"] += form_generation_results["tests_failed"]
            results["test_results"].extend(form_generation_results["test_results"])
        
        # Run subscription tier tests
        if test_type == "all" or test_type == "subscription_tiers":
            subscription_tier_results = run_subscription_tier_tests()
            results["tests_run"] += subscription_tier_results["tests_run"]
            results["tests_passed"] += subscription_tier_results["tests_passed"]
            results["tests_failed"] += subscription_tier_results["tests_failed"]
            results["test_results"].extend(subscription_tier_results["test_results"])
        
        # Run security tests
        if test_type == "all" or test_type == "security":
            security_results = run_security_tests()
            results["tests_run"] += security_results["tests_run"]
            results["tests_passed"] += security_results["tests_passed"]
            results["tests_failed"] += security_results["tests_failed"]
            results["test_results"].extend(security_results["test_results"])
        
        # Run mobile responsiveness tests
        if test_type == "all" or test_type == "mobile_responsiveness":
            mobile_results = run_mobile_responsiveness_tests()
            results["tests_run"] += mobile_results["tests_run"]
            results["tests_passed"] += mobile_results["tests_passed"]
            results["tests_failed"] += mobile_results["tests_failed"]
            results["test_results"].extend(mobile_results["test_results"])
        
        # Update success flag if any tests failed
        if results["tests_failed"] > 0:
            results["success"] = False
        
        return jsonify(results)
    
    except Exception as e:
        logger.error(f"Error running validation tests: {str(e)}")
        return jsonify({
            "success": False,
            "message": f"An error occurred: {str(e)}",
            "tests_run": 0,
            "tests_passed": 0,
            "tests_failed": 0,
            "test_results": []
        }), 500

def run_user_flow_tests():
    """Run tests for user flows"""
    results = {
        "tests_run": 0,
        "tests_passed": 0,
        "tests_failed": 0,
        "test_results": []
    }
    
    # Test 1: Business Profile Creation
    results["tests_run"] += 1
    try:
        # Create test user if needed
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            test_user = User(
                email="test@example.com",
                username="testuser",
                plan="premium"
            )
            test_user.set_password("testpassword")
            db.session.add(test_user)
            db.session.commit()
        
        # Create or update business profile
        profile = BusinessProfile.query.filter_by(user_id=test_user.id).first()
        if not profile:
            profile = BusinessProfile(
                user_id=test_user.id,
                business_name="Test Business",
                business_type="sole_proprietor",
                ein="12-3456789",
                business_address="123 Test St, Test City, TS 12345",
                business_phone="555-123-4567",
                business_email="business@example.com",
                industry="technology",
                annual_revenue=75000,
                tax_year=2024,
                has_employees=False,
                employee_count=0,
                contractor_count=1,
                operating_states=json.dumps(["CA", "NY"]),
                has_home_office=True,
                has_vehicle=True,
                has_travel_expenses=True,
                has_equipment_purchases=True
            )
            db.session.add(profile)
        else:
            profile.business_name = "Test Business"
            profile.business_type = "sole_proprietor"
            profile.ein = "12-3456789"
            profile.business_address = "123 Test St, Test City, TS 12345"
            profile.business_phone = "555-123-4567"
            profile.business_email = "business@example.com"
            profile.industry = "technology"
            profile.annual_revenue = 75000
            profile.tax_year = 2024
            profile.has_employees = False
            profile.employee_count = 0
            profile.contractor_count = 1
            profile.operating_states = json.dumps(["CA", "NY"])
            profile.has_home_office = True
            profile.has_vehicle = True
            profile.has_travel_expenses = True
            profile.has_equipment_purchases = True
        
        db.session.commit()
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Business Profile Creation",
            "status": "passed",
            "message": "Successfully created/updated business profile"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Business Profile Creation",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 2: Tax Form Recommendation
    results["tests_run"] += 1
    try:
        # Get test user
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            raise Exception("Test user not found")
        
        # Get business profile
        profile = BusinessProfile.query.filter_by(user_id=test_user.id).first()
        if not profile:
            raise Exception("Business profile not found")
        
        # Generate form recommendations based on business type
        recommended_forms = []
        
        # Convert enum to string if needed
        business_type = profile.business_type
        if hasattr(business_type, 'value'):
            business_type = business_type.value
        
        # Basic form recommendations by business type
        if business_type == "sole_proprietor":
            recommended_forms = [
                {"id": "schedule_c", "name": "Schedule C", "description": "Profit or Loss From Business", "required": True},
                {"id": "schedule_se", "name": "Schedule SE", "description": "Self-Employment Tax", "required": True},
                {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases},
                {"id": "form_8829", "name": "Form 8829", "description": "Expenses for Business Use of Your Home", "required": profile.has_home_office}
            ]
        
        # Verify recommendations
        if len(recommended_forms) == 0:
            raise Exception("No form recommendations generated")
        
        # Verify required forms for sole proprietor
        if business_type == "sole_proprietor":
            required_forms = ["schedule_c", "schedule_se"]
            for form_id in required_forms:
                found = False
                for form in recommended_forms:
                    if form["id"] == form_id and form["required"]:
                        found = True
                        break
                if not found:
                    raise Exception(f"Required form {form_id} not found in recommendations")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Tax Form Recommendation",
            "status": "passed",
            "message": f"Successfully generated {len(recommended_forms)} form recommendations"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Tax Form Recommendation",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 3: Form Filling
    results["tests_run"] += 1
    try:
        # Get test user
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            raise Exception("Test user not found")
        
        # Create test form data
        form_data = {
            "business_info": {
                "business_name": "Test Business",
                "business_address": "123 Test St, Test City, TS 12345",
                "ein": "12-3456789",
                "accounting_method": "cash"
            },
            "income": {
                "gross_receipts": "75000",
                "returns": "0",
                "other_income": "500"
            },
            "expenses": {
                "advertising": "1200",
                "car_expenses": "3500",
                "commissions": "0",
                "insurance": "1800",
                "legal_fees": "500",
                "office_expenses": "2400",
                "rent": "0",
                "repairs": "300",
                "supplies": "1500",
                "taxes": "2000",
                "travel": "1200",
                "meals": "800",
                "utilities": "1800",
                "wages": "0",
                "other_expenses": "1000"
            }
        }
        
        # Save form data
        form = TaxForm.query.filter_by(
            user_id=test_user.id,
            form_type="schedule_c",
            tax_year=2024
        ).first()
        
        if form:
            form.data = form_data
            form.updated_at = datetime.utcnow()
            form.status = "draft"
        else:
            form = TaxForm(
                user_id=test_user.id,
                form_type="schedule_c",
                tax_year=2024,
                data=form_data,
                status="draft"
            )
            db.session.add(form)
        
        db.session.commit()
        
        # Verify form was saved
        saved_form = TaxForm.query.filter_by(
            user_id=test_user.id,
            form_type="schedule_c",
            tax_year=2024
        ).first()
        
        if not saved_form:
            raise Exception("Form not saved to database")
        
        if not saved_form.data or "business_info" not in saved_form.data:
            raise Exception("Form data not saved correctly")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Form Filling",
            "status": "passed",
            "message": "Successfully saved form data"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Form Filling",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 4: Document Upload
    results["tests_run"] += 1
    try:
        # Get test user
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            raise Exception("Test user not found")
        
        # Create test document
        document = DocumentAccess.query.filter_by(
            user_id=test_user.id,
            document_name="Test Document"
        ).first()
        
        if not document:
            # Create upload directory if it doesn't exist
            upload_dir = os.path.join(os.getcwd(), 'secure_documents')
            os.makedirs(upload_dir, exist_ok=True)
            
            # Create test file
            test_file_path = os.path.join(upload_dir, "test_document.txt")
            with open(test_file_path, "w") as f:
                f.write("This is a test document")
            
            # Create document record
            document = DocumentAccess(
                user_id=test_user.id,
                document_name="Test Document",
                document_type="income_documents",
                filename="test_document.txt",
                file_size=os.path.getsize(test_file_path),
                content_type="text/plain"
            )
            db.session.add(document)
            
            # Create history record
            history = DocumentHistory(
                user_id=test_user.id,
                document_id=document.id,
                action="upload",
                details="Uploaded test document"
            )
            db.session.add(history)
            
            db.session.commit()
        
        # Verify document was saved
        saved_document = DocumentAccess.query.filter_by(
            user_id=test_user.id,
            document_name="Test Document"
        ).first()
        
        if not saved_document:
            raise Exception("Document not saved to database")
        
        # Verify history was created
        history = DocumentHistory.query.filter_by(
            user_id=test_user.id,
            document_id=saved_document.id
        ).first()
        
        if not history:
            raise Exception("Document history not created")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Document Upload",
            "status": "passed",
            "message": "Successfully saved document and history"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Document Upload",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    return results

def run_form_generation_tests():
    """Run tests for form generation accuracy"""
    results = {
        "tests_run": 0,
        "tests_passed": 0,
        "tests_failed": 0,
        "test_results": []
    }
    
    # Test 1: Schedule C Generation
    results["tests_run"] += 1
    try:
        # Get test user
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            raise Exception("Test user not found")
        
        # Get form data
        form = TaxForm.query.filter_by(
            user_id=test_user.id,
            form_type="schedule_c",
            tax_year=2024
        ).first()
        
        if not form or not form.data:
            raise Exception("Form data not found")
        
        # Calculate expected values
        form_data = form.data
        
        # Gross income calculation
        gross_receipts = float(form_data["income"]["gross_receipts"])
        returns = float(form_data["income"]["returns"])
        other_income = float(form_data["income"]["other_income"])
        expected_gross_income = gross_receipts - returns + other_income
        
        # Total expenses calculation
        total_expenses = 0
        for expense, amount in form_data["expenses"].items():
            total_expenses += float(amount)
        
        # Net profit calculation
        expected_net_profit = expected_gross_income - total_expenses
        
        # These calculations would normally be done by the form generation code
        # Here we're just verifying the math is correct
        
        if expected_gross_income != 75500:
            raise Exception(f"Expected gross income to be 75500, got {expected_gross_income}")
        
        if total_expenses != 18000:
            raise Exception(f"Expected total expenses to be 18000, got {total_expenses}")
        
        if expected_net_profit != 57500:
            raise Exception(f"Expected net profit to be 57500, got {expected_net_profit}")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Schedule C Generation",
            "status": "passed",
            "message": "Form calculations are correct"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Schedule C Generation",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 2: Self-Employment Tax Calculation
    results["tests_run"] += 1
    try:
        # Get test user
        test_user = User.query.filter_by(email="test@example.com").first()
        if not test_user:
            raise Exception("Test user not found")
        
        # Get form data
        form = TaxForm.query.filter_by(
            user_id=test_user.id,
            form_type="schedule_c",
            tax_year=2024
        ).first()
        
        if not form or not form.data:
            raise Exception("Form data not found")
        
        # Calculate expected values
        form_data = form.data
        
        # Gross income calculation
        gross_receipts = float(form_data["income"]["gross_receipts"])
        returns = float(form_data["income"]["returns"])
        other_income = float(form_data["income"]["other_income"])
        gross_income = gross_receipts - returns + other_income
        
        # Total expenses calculation
        total_expenses = 0
        for expense, amount in form_data["expenses"].items():
            total_expenses += float(amount)
        
        # Net profit calculation
        net_profit = gross_income - total_expenses
        
        # Self-employment tax calculation (2024 rates)
        se_tax_rate = 0.153  # 15.3% (12.4% Social Security + 2.9% Medicare)
        se_tax_income = net_profit * 0.9235  # Only 92.35% of net profit is subject to SE tax
        expected_se_tax = se_tax_income * se_tax_rate
        
        # These calculations would normally be done by the form generation code
        # Here we're just verifying the math is correct
        
        if abs(expected_se_tax - 8138.78) > 0.01:
            raise Exception(f"Expected self-employment tax to be approximately 8138.78, got {expected_se_tax}")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Self-Employment Tax Calculation",
            "status": "passed",
            "message": "Self-employment tax calculation is correct"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Self-Employment Tax Calculation",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    return results

def run_subscription_tier_tests():
    """Run tests for subscription tier functionality"""
    results = {
        "tests_run": 0,
        "tests_passed": 0,
        "tests_failed": 0,
        "test_results": []
    }
    
    # Test 1: Free Tier Access
    results["tests_run"] += 1
    try:
        # Create test user if needed
        free_user = User.query.filter_by(email="free@example.com").first()
        if not free_user:
            free_user = User(
                email="free@example.com",
                username="freeuser",
                plan="free"
            )
            free_user.set_password("testpassword")
            db.session.add(free_user)
            db.session.commit()
        else:
            free_user.plan = "free"
            db.session.commit()
        
        # Verify free tier features
        from app.access_control import has_access
        
        # Features that should be accessible
        free_features = ["guided_input", "auto_fill", "form_generation", "pdf_export", "educational_guidance"]
        for feature in free_features:
            if not has_access(free_user, feature):
                raise Exception(f"Free user should have access to {feature}")
        
        # Features that should not be accessible
        premium_features = ["save_progress", "smart_form_logic", "enhanced_ai_support"]
        for feature in premium_features:
            if has_access(free_user, feature):
                raise Exception(f"Free user should not have access to {feature}")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Free Tier Access",
            "status": "passed",
            "message": "Free tier access controls working correctly"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Free Tier Access",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 2: Premium Tier Access
    results["tests_run"] += 1
    try:
        # Create test user if needed
        premium_user = User.query.filter_by(email="premium@example.com").first()
        if not premium_user:
            premium_user = User(
                email="premium@example.com",
                username="premiumuser",
                plan="premium"
            )
            premium_user.set_password("testpassword")
            db.session.add(premium_user)
            db.session.commit()
        else:
            premium_user.plan = "premium"
            db.session.commit()
        
        # Verify premium tier features
        from app.access_control import has_access
        
        # Features that should be accessible
        premium_features = [
            "guided_input", "auto_fill", "form_generation", "pdf_export", "educational_guidance",
            "save_progress", "smart_form_logic", "enhanced_ai_support", "dynamic_checklist", "export_forms"
        ]
        for feature in premium_features:
            if not has_access(premium_user, feature):
                raise Exception(f"Premium user should have access to {feature}")
        
        # Features that should not be accessible
        pro_features = ["ai_deduction_detection", "ai_sorted_uploads", "audit_protection"]
        for feature in pro_features:
            if has_access(premium_user, feature):
                raise Exception(f"Premium user should not have access to {feature}")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Premium Tier Access",
            "status": "passed",
            "message": "Premium tier access controls working correctly"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Premium Tier Access",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 3: Pro Tier Access
    results["tests_run"] += 1
    try:
        # Create test user if needed
        pro_user = User.query.filter_by(email="pro@example.com").first()
        if not pro_user:
            pro_user = User(
                email="pro@example.com",
                username="prouser",
                plan="pro"
            )
            pro_user.set_password("testpassword")
            db.session.add(pro_user)
            db.session.commit()
        else:
            pro_user.plan = "pro"
            db.session.commit()
        
        # Verify pro tier features
        from app.access_control import has_access
        
        # All features should be accessible
        all_features = [
            "guided_input", "auto_fill", "form_generation", "pdf_export", "educational_guidance",
            "save_progress", "smart_form_logic", "enhanced_ai_support", "dynamic_checklist", "export_forms",
            "ai_deduction_detection", "ai_sorted_uploads", "filing_export_support", "audit_protection", "priority_support"
        ]
        for feature in all_features:
            if not has_access(pro_user, feature):
                raise Exception(f"Pro user should have access to {feature}")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Pro Tier Access",
            "status": "passed",
            "message": "Pro tier access controls working correctly"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Pro Tier Access",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    return results

def run_security_tests():
    """Run security tests"""
    results = {
        "tests_run": 0,
        "tests_passed": 0,
        "tests_failed": 0,
        "test_results": []
    }
    
    # Test 1: Document Access Control
    results["tests_run"] += 1
    try:
        # Create test users if needed
        user1 = User.query.filter_by(email="user1@example.com").first()
        if not user1:
            user1 = User(
                email="user1@example.com",
                username="user1",
                plan="premium"
            )
            user1.set_password("testpassword")
            db.session.add(user1)
            db.session.commit()
        
        user2 = User.query.filter_by(email="user2@example.com").first()
        if not user2:
            user2 = User(
                email="user2@example.com",
                username="user2",
                plan="premium"
            )
            user2.set_password("testpassword")
            db.session.add(user2)
            db.session.commit()
        
        # Create test document for user1
        document = DocumentAccess.query.filter_by(
            user_id=user1.id,
            document_name="Security Test Document"
        ).first()
        
        if not document:
            # Create upload directory if it doesn't exist
            upload_dir = os.path.join(os.getcwd(), 'secure_documents')
            os.makedirs(upload_dir, exist_ok=True)
            
            # Create test file
            test_file_path = os.path.join(upload_dir, "security_test_document.txt")
            with open(test_file_path, "w") as f:
                f.write("This is a security test document")
            
            # Create document record
            document = DocumentAccess(
                user_id=user1.id,
                document_name="Security Test Document",
                document_type="income_documents",
                filename="security_test_document.txt",
                file_size=os.path.getsize(test_file_path),
                content_type="text/plain"
            )
            db.session.add(document)
            db.session.commit()
        
        # Verify document access control
        from app.tier_management import verify_document_token, encrypt_document_id
        
        # Generate token
        token = encrypt_document_id(document.id)
        
        # Verify token
        document_id = verify_document_token(token)
        if document_id != document.id:
            raise Exception(f"Token verification failed. Expected {document.id}, got {document_id}")
        
        # Verify document access
        # In a real test, we would simulate HTTP requests with different user sessions
        # Here we're just checking the database relationships
        
        # User1 should have access to the document
        user1_documents = DocumentAccess.query.filter_by(user_id=user1.id).all()
        if document.id not in [d.id for d in user1_documents]:
            raise Exception("User1 should have access to the document")
        
        # User2 should not have access to the document
        user2_documents = DocumentAccess.query.filter_by(user_id=user2.id).all()
        if document.id in [d.id for d in user2_documents]:
            raise Exception("User2 should not have access to the document")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Document Access Control",
            "status": "passed",
            "message": "Document access controls working correctly"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Document Access Control",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 2: Password Security
    results["tests_run"] += 1
    try:
        # Create test user if needed
        security_user = User.query.filter_by(email="security@example.com").first()
        if not security_user:
            security_user = User(
                email="security@example.com",
                username="securityuser",
                plan="free"
            )
            security_user.set_password("TestPassword123!")
            db.session.add(security_user)
            db.session.commit()
        
        # Verify password hashing
        if security_user.password_hash == "TestPassword123!":
            raise Exception("Password is stored in plaintext")
        
        # Verify password verification
        if not security_user.check_password("TestPassword123!"):
            raise Exception("Password verification failed")
        
        # Verify incorrect password fails
        if security_user.check_password("WrongPassword"):
            raise Exception("Incorrect password should fail verification")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Password Security",
            "status": "passed",
            "message": "Password security mechanisms working correctly"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Password Security",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    return results

def run_mobile_responsiveness_tests():
    """Run mobile responsiveness tests"""
    results = {
        "tests_run": 0,
        "tests_passed": 0,
        "tests_failed": 0,
        "test_results": []
    }
    
    # Test 1: Viewport Meta Tag
    results["tests_run"] += 1
    try:
        # Check if viewport meta tag is present in layout.html
        layout_path = os.path.join(os.getcwd(), 'templates', 'layout.html')
        if os.path.exists(layout_path):
            with open(layout_path, 'r') as f:
                layout_content = f.read()
                
                if 'viewport' not in layout_content or 'width=device-width' not in layout_content:
                    raise Exception("Viewport meta tag missing or incomplete in layout.html")
        else:
            # Check if we can find it in the project structure
            found = False
            for root, dirs, files in os.walk(os.path.join(os.getcwd(), 'templates')):
                for file in files:
                    if file.endswith('.html'):
                        with open(os.path.join(root, file), 'r') as f:
                            content = f.read()
                            if 'viewport' in content and 'width=device-width' in content:
                                found = True
                                break
                if found:
                    break
            
            if not found:
                raise Exception("Viewport meta tag not found in any template file")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Viewport Meta Tag",
            "status": "passed",
            "message": "Viewport meta tag is present"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Viewport Meta Tag",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 2: Mobile CSS
    results["tests_run"] += 1
    try:
        # Check if mobile-specific CSS exists
        mobile_css_path = os.path.join(os.getcwd(), 'static', 'css', 'mobile-optimizations.css')
        if not os.path.exists(mobile_css_path):
            # Try to find it in the project structure
            found = False
            for root, dirs, files in os.walk(os.path.join(os.getcwd(), 'static', 'css')):
                for file in files:
                    if 'mobile' in file.lower() and file.endswith('.css'):
                        mobile_css_path = os.path.join(root, file)
                        found = True
                        break
                if found:
                    break
            
            if not found:
                raise Exception("Mobile-specific CSS file not found")
        
        # Check if mobile CSS contains media queries
        with open(mobile_css_path, 'r') as f:
            css_content = f.read()
            if '@media' not in css_content or 'max-width' not in css_content:
                raise Exception("Mobile CSS does not contain media queries")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Mobile CSS",
            "status": "passed",
            "message": "Mobile-specific CSS with media queries is present"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Mobile CSS",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    # Test 3: Touch-Friendly UI
    results["tests_run"] += 1
    try:
        # Check if mobile-specific JavaScript exists
        mobile_js_path = os.path.join(os.getcwd(), 'static', 'js', 'mobile-enhancements.js')
        if not os.path.exists(mobile_js_path):
            # Try to find it in the project structure
            found = False
            for root, dirs, files in os.walk(os.path.join(os.getcwd(), 'static', 'js')):
                for file in files:
                    if 'mobile' in file.lower() and file.endswith('.js'):
                        mobile_js_path = os.path.join(root, file)
                        found = True
                        break
                if found:
                    break
            
            if not found:
                raise Exception("Mobile-specific JavaScript file not found")
        
        # Check if mobile JS contains touch event handling
        with open(mobile_js_path, 'r') as f:
            js_content = f.read()
            if 'touch' not in js_content.lower() and 'click' not in js_content.lower():
                raise Exception("Mobile JavaScript does not contain touch event handling")
        
        results["tests_passed"] += 1
        results["test_results"].append({
            "name": "Touch-Friendly UI",
            "status": "passed",
            "message": "Touch-friendly UI enhancements are present"
        })
    except Exception as e:
        results["tests_failed"] += 1
        results["test_results"].append({
            "name": "Touch-Friendly UI",
            "status": "failed",
            "message": f"Error: {str(e)}"
        })
    
    return results

@validation_bp.route("/validation-report")
@login_required
@requires_access_level("admin")
def validation_report():
    """Generate validation report"""
    # Get validation results from session or run tests
    validation_results = session.get("validation_results")
    if not validation_results:
        # Run all tests
        results = {
            "success": True,
            "tests_run": 0,
            "tests_passed": 0,
            "tests_failed": 0,
            "test_results": []
        }
        
        # Run user flow tests
        user_flow_results = run_user_flow_tests()
        results["tests_run"] += user_flow_results["tests_run"]
        results["tests_passed"] += user_flow_results["tests_passed"]
        results["tests_failed"] += user_flow_results["tests_failed"]
        results["test_results"].extend(user_flow_results["test_results"])
        
        # Run form generation tests
        form_generation_results = run_form_generation_tests()
        results["tests_run"] += form_generation_results["tests_run"]
        results["tests_passed"] += form_generation_results["tests_passed"]
        results["tests_failed"] += form_generation_results["tests_failed"]
        results["test_results"].extend(form_generation_results["test_results"])
        
        # Run subscription tier tests
        subscription_tier_results = run_subscription_tier_tests()
        results["tests_run"] += subscription_tier_results["tests_run"]
        results["tests_passed"] += subscription_tier_results["tests_passed"]
        results["tests_failed"] += subscription_tier_results["tests_failed"]
        results["test_results"].extend(subscription_tier_results["test_results"])
        
        # Run security tests
        security_results = run_security_tests()
        results["tests_run"] += security_results["tests_run"]
        results["tests_passed"] += security_results["tests_passed"]
        results["tests_failed"] += security_results["tests_failed"]
        results["test_results"].extend(security_results["test_results"])
        
        # Run mobile responsiveness tests
        mobile_results = run_mobile_responsiveness_tests()
        results["tests_run"] += mobile_results["tests_run"]
        results["tests_passed"] += mobile_results["tests_passed"]
        results["tests_failed"] += mobile_results["tests_failed"]
        results["test_results"].extend(mobile_results["test_results"])
        
        # Update success flag if any tests failed
        if results["tests_failed"] > 0:
            results["success"] = False
        
        validation_results = results
        session["validation_results"] = results
    
    return render_template(
        "validation/validation_report.html",
        results=validation_results
    )

@validation_bp.route("/clear-validation-results")
@login_required
@requires_access_level("admin")
def clear_validation_results():
    """Clear validation results from session"""
    if "validation_results" in session:
        del session["validation_results"]
    
    flash("Validation results cleared", "success")
    return redirect(url_for("validation.test_dashboard"))
