"""
Firebase Authentication backend integration for .fylr

This module handles Firebase ID token verification and user session management.
"""
from flask import Blueprint, request, jsonify, redirect, url_for, current_app
from flask_login import login_user, current_user
from firebase_admin import auth as firebase_auth
from app.models import User, db
import firebase_admin
from firebase_admin import credentials
import os
import json

# Create blueprint
firebase_auth_bp = Blueprint('firebase_auth', __name__)

# Initialize Firebase Admin SDK if not already initialized
def init_firebase_admin():
    """Initialize Firebase Admin SDK if not already initialized"""
    if not firebase_admin._apps:
        # Check for service account key file
        service_account_path = os.environ.get('FIREBASE_SERVICE_ACCOUNT_PATH', 'firebase-service-account.json')
        
        # If service account file exists, use it
        if os.path.exists(service_account_path):
            cred = credentials.Certificate(service_account_path)
        else:
            # Otherwise, use application default credentials or environment variables
            # This is useful for production environments like Google Cloud
            cred = credentials.ApplicationDefault()
        
        firebase_admin.initialize_app(cred)

# Initialize Firebase Admin when the blueprint is registered
@firebase_auth_bp.record_once
def on_load(state):
    init_firebase_admin()

@firebase_auth_bp.route('/verify', methods=['POST'])
def verify_firebase_token():
    """Verify Firebase ID token and create user session"""
    # Get the ID token from the request
    request_data = request.get_json()
    if not request_data or 'idToken' not in request_data:
        return jsonify({'error': 'No ID token provided'}), 400
    
    id_token = request_data['idToken']
    
    try:
        # Verify the ID token with Firebase Admin SDK
        decoded_token = firebase_auth.verify_id_token(id_token)
        
        # Get user info from the decoded token
        firebase_uid = decoded_token['uid']
        email = decoded_token.get('email', '')
        name = decoded_token.get('name', '')
        
        # If email is not verified and required, reject the token
        if current_app.config.get('REQUIRE_EMAIL_VERIFICATION', True) and not decoded_token.get('email_verified', False):
            return jsonify({'error': 'Email not verified'}), 403
        
        # Check if user exists in our database
        user = User.query.filter_by(firebase_uid=firebase_uid).first()
        
        if not user:
            # Check if a user with this email already exists
            existing_user = User.query.filter_by(email=email).first() if email else None
            
            if existing_user:
                # Link existing user to Firebase UID
                existing_user.firebase_uid = firebase_uid
                db.session.commit()
                user = existing_user
            else:
                # Create a new user
                username = email.split('@')[0] if email else f"user_{firebase_uid[:8]}"
                
                # Ensure username is unique
                base_username = username
                counter = 1
                while User.query.filter_by(username=username).first():
                    username = f"{base_username}_{counter}"
                    counter += 1
                
                user = User(
                    username=username,
                    email=email,
                    firebase_uid=firebase_uid,
                    # No password_hash needed for Firebase users
                )
                
                # Add user to database
                db.session.add(user)
                db.session.commit()
        
        # Log in the user with Flask-Login
        login_user(user)
        
        # Return success response with redirect URL
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'username': user.username,
                'email': user.email
            },
            'redirect': url_for('main.dashboard')
        })
    
    except firebase_auth.InvalidIdTokenError:
        return jsonify({'error': 'Invalid ID token'}), 401
    
    except firebase_auth.ExpiredIdTokenError:
        return jsonify({'error': 'Expired ID token'}), 401
    
    except firebase_auth.RevokedIdTokenError:
        return jsonify({'error': 'Revoked ID token'}), 401
    
    except firebase_auth.CertificateFetchError:
        return jsonify({'error': 'Could not fetch certificates'}), 500
    
    except Exception as e:
        current_app.logger.error(f"Error verifying Firebase token: {str(e)}")
        return jsonify({'error': 'Authentication failed'}), 500
