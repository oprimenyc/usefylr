import os
import json
import logging
from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify, session
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.models import User, BusinessProfile, TaxForm, TaxStrategy, QuestionnaireResponse
from app import db
from app.access_control import requires_access_level
from ai.enhanced_openai_interface import get_openai_response, analyze_image, get_entity_specific_prompt
from datetime import datetime

# Create blueprint
automation_bp = Blueprint("automation", __name__, url_prefix="/automation")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define allowed file extensions for document uploads
ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png', 'tiff', 'tif', 'doc', 'docx', 'xls', 'xlsx', 'csv'}

def allowed_file(filename):
    """Check if file has an allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@automation_bp.route("/business-profile", methods=["GET", "POST"])
@login_required
def business_profile_wizard():
    """Interactive business profile setup wizard"""
    # Check if user already has a business profile
    existing_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if request.method == "POST":
        # Process form submission
        try:
            # Get form data
            business_name = request.form.get("business_name")
            business_type = request.form.get("business_type")
            ein = request.form.get("ein")
            business_address = request.form.get("business_address")
            business_phone = request.form.get("business_phone")
            business_email = request.form.get("business_email")
            industry = request.form.get("industry")
            annual_revenue = float(request.form.get("annual_revenue", 0))
            tax_year = int(request.form.get("tax_year", datetime.utcnow().year))
            has_employees = request.form.get("has_employees") == "yes"
            employee_count = int(request.form.get("employee_count", 0))
            contractor_count = int(request.form.get("contractor_count", 0))
            operating_states = json.dumps(request.form.getlist("operating_states"))
            
            # Additional deduction-relevant fields
            has_home_office = request.form.get("has_home_office") == "yes"
            has_vehicle = request.form.get("has_vehicle") == "yes"
            has_travel_expenses = request.form.get("has_travel_expenses") == "yes"
            has_equipment_purchases = request.form.get("has_equipment_purchases") == "yes"
            
            # Create or update business profile
            if existing_profile:
                # Update existing profile
                existing_profile.business_name = business_name
                existing_profile.business_type = business_type
                existing_profile.ein = ein
                existing_profile.business_address = business_address
                existing_profile.business_phone = business_phone
                existing_profile.business_email = business_email
                existing_profile.industry = industry
                existing_profile.annual_revenue = annual_revenue
                existing_profile.tax_year = tax_year
                existing_profile.has_employees = has_employees
                existing_profile.employee_count = employee_count
                existing_profile.contractor_count = contractor_count
                existing_profile.operating_states = operating_states
                existing_profile.has_home_office = has_home_office
                existing_profile.has_vehicle = has_vehicle
                existing_profile.has_travel_expenses = has_travel_expenses
                existing_profile.has_equipment_purchases = has_equipment_purchases
                existing_profile.updated_at = datetime.utcnow()
                
                db.session.commit()
                flash("Business profile updated successfully!", "success")
            else:
                # Create new profile
                new_profile = BusinessProfile(
                    user_id=current_user.id,
                    business_name=business_name,
                    business_type=business_type,
                    ein=ein,
                    business_address=business_address,
                    business_phone=business_phone,
                    business_email=business_email,
                    industry=industry,
                    annual_revenue=annual_revenue,
                    tax_year=tax_year,
                    has_employees=has_employees,
                    employee_count=employee_count,
                    contractor_count=contractor_count,
                    operating_states=operating_states,
                    has_home_office=has_home_office,
                    has_vehicle=has_vehicle,
                    has_travel_expenses=has_travel_expenses,
                    has_equipment_purchases=has_equipment_purchases
                )
                
                db.session.add(new_profile)
                db.session.commit()
                flash("Business profile created successfully!", "success")
            
            # Redirect to dashboard or next step
            return redirect(url_for("automation.tax_form_recommendations"))
            
        except Exception as e:
            logger.error(f"Error saving business profile: {str(e)}")
            flash("An error occurred while saving your business profile. Please try again.", "danger")
            db.session.rollback()
    
    # Render the form
    return render_template(
        "automation/business_profile.html",
        profile=existing_profile
    )

@automation_bp.route("/tax-form-recommendations")
@login_required
def tax_form_recommendations():
    """Generate tax form recommendations based on business profile"""
    # Get user's business profile
    profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not profile:
        flash("Please complete your business profile first.", "warning")
        return redirect(url_for("automation.business_profile_wizard"))
    
    # Generate form recommendations based on business type
    recommended_forms = []
    
    # Convert enum to string if needed
    business_type = profile.business_type
    if hasattr(business_type, 'value'):
        business_type = business_type.value
    
    # Basic form recommendations by business type
    if business_type == "sole_proprietor":
        recommended_forms = [
            {"id": "schedule_c", "name": "Schedule C", "description": "Profit or Loss From Business", "required": True},
            {"id": "schedule_se", "name": "Schedule SE", "description": "Self-Employment Tax", "required": True},
            {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases},
            {"id": "form_8829", "name": "Form 8829", "description": "Expenses for Business Use of Your Home", "required": profile.has_home_office}
        ]
    elif business_type == "llc":
        # For single-member LLC taxed as sole proprietor
        if profile.employee_count == 0 and profile.contractor_count == 0:
            recommended_forms = [
                {"id": "schedule_c", "name": "Schedule C", "description": "Profit or Loss From Business", "required": True},
                {"id": "schedule_se", "name": "Schedule SE", "description": "Self-Employment Tax", "required": True},
                {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases},
                {"id": "form_8829", "name": "Form 8829", "description": "Expenses for Business Use of Your Home", "required": profile.has_home_office}
            ]
        else:
            # For multi-member LLC taxed as partnership
            recommended_forms = [
                {"id": "form_1065", "name": "Form 1065", "description": "U.S. Return of Partnership Income", "required": True},
                {"id": "schedule_k1", "name": "Schedule K-1", "description": "Partner's Share of Income, Deductions, Credits, etc.", "required": True},
                {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases}
            ]
    elif business_type == "s_corp":
        recommended_forms = [
            {"id": "form_1120s", "name": "Form 1120-S", "description": "U.S. Income Tax Return for an S Corporation", "required": True},
            {"id": "schedule_k1", "name": "Schedule K-1", "description": "Shareholder's Share of Income, Deductions, Credits, etc.", "required": True},
            {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases}
        ]
    elif business_type == "c_corp":
        recommended_forms = [
            {"id": "form_1120", "name": "Form 1120", "description": "U.S. Corporation Income Tax Return", "required": True},
            {"id": "form_4562", "name": "Form 4562", "description": "Depreciation and Amortization", "required": profile.has_equipment_purchases}
        ]
    
    # Add employment tax forms if applicable
    if profile.has_employees:
        employment_forms = [
            {"id": "form_941", "name": "Form 941", "description": "Employer's Quarterly Federal Tax Return", "required": True},
            {"id": "form_940", "name": "Form 940", "description": "Employer's Annual Federal Unemployment (FUTA) Tax Return", "required": True},
            {"id": "form_w2", "name": "Form W-2", "description": "Wage and Tax Statement", "required": True},
            {"id": "form_w3", "name": "Form W-3", "description": "Transmittal of Wage and Tax Statements", "required": True}
        ]
        recommended_forms.extend(employment_forms)
    
    # Add contractor forms if applicable
    if profile.contractor_count > 0:
        contractor_forms = [
            {"id": "form_1099nec", "name": "Form 1099-NEC", "description": "Nonemployee Compensation", "required": True},
            {"id": "form_1096", "name": "Form 1096", "description": "Annual Summary and Transmittal of U.S. Information Returns", "required": True}
        ]
        recommended_forms.extend(contractor_forms)
    
    # Store recommendations in session for later use
    session['recommended_forms'] = recommended_forms
    
    return render_template(
        "automation/tax_form_recommendations.html",
        profile=profile,
        recommended_forms=recommended_forms
    )

@automation_bp.route("/form-fill/<form_id>")
@login_required
def form_fill(form_id):
    """Interactive form filling wizard"""
    # Get user's business profile
    profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not profile:
        flash("Please complete your business profile first.", "warning")
        return redirect(url_for("automation.business_profile_wizard"))
    
    # Get form details
    form_details = {
        "schedule_c": {
            "name": "Schedule C (Form 1040)",
            "title": "Profit or Loss From Business",
            "description": "Use Schedule C to report income or loss from a business you operated or a profession you practiced as a sole proprietor.",
            "sections": [
                {"id": "business_info", "name": "Business Information", "fields": ["business_name", "business_address", "ein", "accounting_method"]},
                {"id": "income", "name": "Income", "fields": ["gross_receipts", "returns", "other_income"]},
                {"id": "expenses", "name": "Expenses", "fields": ["advertising", "car_expenses", "commissions", "insurance", "legal_fees", "office_expenses", "rent", "repairs", "supplies", "taxes", "travel", "meals", "utilities", "wages", "other_expenses"]},
                {"id": "cost_of_goods", "name": "Cost of Goods Sold", "fields": ["inventory_start", "purchases", "labor_costs", "materials", "inventory_end"]},
                {"id": "vehicle", "name": "Vehicle Information", "fields": ["vehicle_description", "business_miles", "commuting_miles", "other_miles"]}
            ]
        },
        "form_1065": {
            "name": "Form 1065",
            "title": "U.S. Return of Partnership Income",
            "description": "Use Form 1065 to report the income, gains, losses, deductions, credits, etc., from the operation of a partnership.",
            "sections": [
                {"id": "partnership_info", "name": "Partnership Information", "fields": ["partnership_name", "address", "ein", "date_business_started", "principal_business_activity"]},
                {"id": "income", "name": "Income", "fields": ["gross_receipts", "cost_of_goods_sold", "gross_profit", "ordinary_income", "rental_income", "interest_income", "dividend_income"]},
                {"id": "deductions", "name": "Deductions", "fields": ["salaries", "guaranteed_payments", "repairs", "bad_debts", "rent", "taxes", "interest", "depreciation", "retirement_plans", "employee_benefits", "other_deductions"]},
                {"id": "partners", "name": "Partners Information", "fields": ["number_of_partners", "partner_details"]}
            ]
        },
        "form_1120s": {
            "name": "Form 1120-S",
            "title": "U.S. Income Tax Return for an S Corporation",
            "description": "Use Form 1120-S to report the income, gains, losses, deductions, credits, etc., of a domestic corporation that has elected to be an S corporation.",
            "sections": [
                {"id": "corporation_info", "name": "Corporation Information", "fields": ["corporation_name", "address", "ein", "date_incorporated", "principal_business_activity"]},
                {"id": "income", "name": "Income", "fields": ["gross_receipts", "cost_of_goods_sold", "gross_profit", "net_rental_income", "interest_income", "dividend_income"]},
                {"id": "deductions", "name": "Deductions", "fields": ["officer_compensation", "salaries", "repairs", "bad_debts", "rent", "taxes", "interest", "depreciation", "retirement_plans", "employee_benefits", "other_deductions"]},
                {"id": "shareholders", "name": "Shareholders Information", "fields": ["number_of_shareholders", "shareholder_details"]}
            ]
        },
        "form_1120": {
            "name": "Form 1120",
            "title": "U.S. Corporation Income Tax Return",
            "description": "Use Form 1120 to report the income, gains, losses, deductions, credits, and to figure the income tax liability of a corporation.",
            "sections": [
                {"id": "corporation_info", "name": "Corporation Information", "fields": ["corporation_name", "address", "ein", "date_incorporated", "principal_business_activity"]},
                {"id": "income", "name": "Income", "fields": ["gross_receipts", "cost_of_goods_sold", "gross_profit", "dividends", "interest", "gross_rents", "gross_royalties", "capital_gain", "other_income"]},
                {"id": "deductions", "name": "Deductions", "fields": ["officer_compensation", "salaries", "repairs", "bad_debts", "rent", "taxes", "interest", "charitable_contributions", "depreciation", "retirement_plans", "employee_benefits", "other_deductions"]},
                {"id": "tax_computation", "name": "Tax Computation", "fields": ["taxable_income", "tax_rate", "tax_credits", "estimated_tax_payments"]}
            ]
        }
    }
    
    # Check if form exists
    if form_id not in form_details:
        flash(f"Form {form_id} is not available.", "danger")
        return redirect(url_for("automation.tax_form_recommendations"))
    
    # Get form data
    form_data = form_details[form_id]
    
    # Check if form already exists in database
    existing_form = TaxForm.query.filter_by(
        user_id=current_user.id,
        form_type=form_id,
        tax_year=profile.tax_year
    ).first()
    
    # If form exists, load saved data
    saved_data = {}
    if existing_form and existing_form.data:
        saved_data = existing_form.data
    
    return render_template(
        "automation/form_fill.html",
        form_id=form_id,
        form_data=form_data,
        profile=profile,
        saved_data=saved_data
    )

@automation_bp.route("/save-form-data/<form_id>", methods=["POST"])
@login_required
def save_form_data(form_id):
    """Save form data via AJAX"""
    try:
        # Get form data from request
        form_data = request.json
        
        if not form_data:
            return jsonify({"success": False, "message": "No data provided"}), 400
        
        # Get user's business profile for tax year
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        tax_year = profile.tax_year if profile else datetime.utcnow().year
        
        # Check if form already exists
        existing_form = TaxForm.query.filter_by(
            user_id=current_user.id,
            form_type=form_id,
            tax_year=tax_year
        ).first()
        
        if existing_form:
            # Update existing form
            existing_form.data = form_data
            existing_form.updated_at = datetime.utcnow()
            existing_form.status = "draft"
            db.session.commit()
        else:
            # Create new form
            new_form = TaxForm(
                user_id=current_user.id,
                form_type=form_id,
                tax_year=tax_year,
                data=form_data,
                status="draft"
            )
            db.session.add(new_form)
            db.session.commit()
        
        return jsonify({"success": True, "message": "Form data saved successfully"})
    
    except Exception as e:
        logger.error(f"Error saving form data: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@automation_bp.route("/field-guidance", methods=["POST"])
@login_required
@requires_access_level("enhanced_ai_support")
def field_guidance():
    """Get AI guidance for a specific form field"""
    try:
        # Get request data
        data = request.json
        form_type = data.get("form_type")
        field_name = data.get("field_name")
        
        if not form_type or not field_name:
            return jsonify({"success": False, "message": "Form type and field name are required"}), 400
        
        # Get user's business profile
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        
        if not profile:
            return jsonify({"success": False, "message": "Business profile not found"}), 404
        
        # Convert enum to string if needed
        business_entity_type = profile.business_type
        if hasattr(business_entity_type, 'value'):
            business_entity_type = business_entity_type.value
        
        # Prepare business context
        business_context = f"Business name: {profile.business_name}, "
        business_context += f"Business type: {business_entity_type}, "
        business_context += f"Industry: {profile.industry}, "
        business_context += f"Annual revenue: ${profile.annual_revenue}, "
        business_context += f"Has employees: {'Yes' if profile.has_employees else 'No'}, "
        business_context += f"Employee count: {profile.employee_count}, "
        business_context += f"Has home office: {'Yes' if profile.has_home_office else 'No'}, "
        business_context += f"Has business vehicle: {'Yes' if profile.has_vehicle else 'No'}"
        
        # Get AI guidance
        params = {
            "form_type": form_type,
            "tax_year": profile.tax_year,
            "field_name": field_name,
            "business_context": business_context
        }
        
        guidance = get_openai_response("tax_form_assistant", params, business_entity_type)
        
        if not guidance:
            return jsonify({"success": False, "message": "Failed to get AI guidance"}), 500
        
        return jsonify({
            "success": True,
            "guidance": guidance
        })
    
    except Exception as e:
        logger.error(f"Error getting field guidance: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@automation_bp.route("/validate-form/<form_id>", methods=["POST"])
@login_required
def validate_form(form_id):
    """Validate form data and provide feedback"""
    try:
        # Get form data from request
        form_data = request.json
        
        if not form_data:
            return jsonify({"success": False, "message": "No data provided"}), 400
        
        # Get user's business profile
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        
        if not profile:
            return jsonify({"success": False, "message": "Business profile not found"}), 404
        
        # Convert enum to string if needed
        business_entity_type = profile.business_type
        if hasattr(business_entity_type, 'value'):
            business_entity_type = business_entity_type.value
        
        # Prepare validation prompt
        validation_prompt = f"Please validate the following tax form data for a {business_entity_type} business:\n\n"
        validation_prompt += f"Form: {form_id}\n"
        validation_prompt += f"Tax Year: {profile.tax_year}\n\n"
        validation_prompt += "Form Data:\n"
        
        # Format form data for the prompt
        for section, fields in form_data.items():
            validation_prompt += f"\n{section.replace('_', ' ').title()}:\n"
            for field, value in fields.items():
                validation_prompt += f"- {field.replace('_', ' ').title()}: {value}\n"
        
        validation_prompt += "\nPlease identify any potential issues, missing required fields, or inconsistencies in this data."
        
        # Get AI validation
        validation_result = get_openai_response("form_validator", validation_prompt, business_entity_type)
        
        if not validation_result:
            return jsonify({"success": False, "message": "Failed to validate form"}), 500
        
        # Save validation results
        existing_form = TaxForm.query.filter_by(
            user_id=current_user.id,
            form_type=form_id,
            tax_year=profile.tax_year
        ).first()
        
        if existing_form:
            existing_form.validation_results = {"validation": validation_result}
            existing_form.updated_at = datetime.utcnow()
            db.session.commit()
        
        return jsonify({
            "success": True,
            "validation_result": validation_result
        })
    
    except Exception as e:
        logger.error(f"Error validating form: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@automation_bp.route("/complete-form/<form_id>", methods=["POST"])
@login_required
def complete_form(form_id):
    """Mark form as complete and generate PDF"""
    try:
        # Get user's business profile
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        
        if not profile:
            return jsonify({"success": False, "message": "Business profile not found"}), 404
        
        # Get form from database
        form = TaxForm.query.filter_by(
            user_id=current_user.id,
            form_type=form_id,
            tax_year=profile.tax_year
        ).first()
        
        if not form:
            return jsonify({"success": False, "message": "Form not found"}), 404
        
        # Update form status
        form.status = "complete"
        form.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Generate PDF (this would be implemented in a separate module)
        # pdf_path = generate_form_pdf(form)
        
        return jsonify({
            "success": True,
            "message": "Form marked as complete",
            "form_id": form.id
        })
    
    except Exception as e:
        logger.error(f"Error completing form: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@automation_bp.route("/document-upload", methods=["GET", "POST"])
@login_required
def document_upload():
    """Document upload and AI analysis"""
    if request.method == "POST":
        # Check if file was uploaded
        if 'file' not in request.files:
            flash('No file selected', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        
        # Check if file was selected
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(request.url)
        
        # Check if file is allowed
        if file and allowed_file(file.filename):
            # Secure the filename
            filename = secure_filename(file.filename)
            
            # Create upload directory if it doesn't exist
            upload_dir = os.path.join(os.getcwd(), 'uploads', str(current_user.id))
            os.makedirs(upload_dir, exist_ok=True)
            
            # Save the file
            file_path = os.path.join(upload_dir, filename)
            file.save(file_path)
            
            # Get document type from form
            document_type = request.form.get('document_type', 'unknown')
            
            # Get user's business profile
            profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
            business_entity_type = None
            if profile and hasattr(profile.business_type, 'value'):
                business_entity_type = profile.business_type.value
            
            # TODO: Implement AI analysis of the document
            # This would convert the document to an image or extract text,
            # then use the AI to analyze it
            
            flash(f'File {filename} uploaded successfully', 'success')
            return redirect(url_for('automation.document_upload'))
        else:
            flash('File type not allowed', 'danger')
            return redirect(request.url)
    
    return render_template('automation/document_upload.html')

@automation_bp.route("/tax-strategy-recommendations")
@login_required
@requires_access_level("ai_deduction_detection")
def tax_strategy_recommendations():
    """Generate tax strategy recommendations based on business profile"""
    # Get user's business profile
    profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not profile:
        flash("Please complete your business profile first.", "warning")
        return redirect(url_for("automation.business_profile_wizard"))
    
    # Convert enum to string if needed
    business_entity_type = profile.business_type
    if hasattr(business_entity_type, 'value'):
        business_entity_type = business_entity_type.value
    
    # Get questionnaire responses if available
    questionnaire = QuestionnaireResponse.query.filter_by(
        user_id=current_user.id,
        tax_year=profile.tax_year,
        questionnaire_type="tax_strategy"
    ).first()
    
    # Prepare business context
    business_context = {
        "business_entity_type": business_entity_type,
        "business_name": profile.business_name,
        "industry": profile.industry,
        "annual_revenue": profile.annual_revenue,
        "has_employees": profile.has_employees,
        "employee_count": profile.employee_count,
        "has_home_office": profile.has_home_office,
        "has_vehicle": profile.has_vehicle,
        "has_travel_expenses": profile.has_travel_expenses,
        "has_equipment_purchases": profile.has_equipment_purchases
    }
    
    # Add questionnaire responses if available
    if questionnaire and questionnaire.responses:
        business_context.update(questionnaire.responses)
    
    # Format answers for the prompt
    answers = ""
    for key, value in business_context.items():
        answers += f"{key.replace('_', ' ').title()}: {value}\n"
    
    # Get AI strategy recommendations
    params = {
        "business_entity_type": business_entity_type,
        "answers": answers
    }
    
    strategies = get_openai_response("strategy_analyzer", params, business_entity_type)
    
    if not strategies:
        flash("Failed to generate tax strategy recommendations. Please try again later.", "danger")
        return redirect(url_for("main.dashboard"))
    
    # Parse strategies (this is simplified; in reality, you'd parse the AI response more carefully)
    strategy_list = []
    strategy_sections = strategies.split("\n\n")
    
    for section in strategy_sections:
        if ":" in section and len(section.strip()) > 0:
            lines = section.strip().split("\n")
            strategy_name = lines[0].split(":")[0].strip()
            description = "\n".join(lines[1:]) if len(lines) > 1 else ""
            
            # Extract estimated savings if present
            estimated_savings = "Varies"
            if "save" in description.lower() or "saving" in description.lower() or "$" in description:
                for line in lines:
                    if "save" in line.lower() or "saving" in line.lower() or "$" in line:
                        estimated_savings = line
                        break
            
            strategy_list.append({
                "name": strategy_name,
                "description": description,
                "estimated_savings": estimated_savings
            })
    
    return render_template(
        "automation/tax_strategy_recommendations.html",
        profile=profile,
        strategies=strategy_list
    )

@automation_bp.route("/save-strategy", methods=["POST"])
@login_required
@requires_access_level("ai_deduction_detection")
def save_strategy():
    """Save a tax strategy to the user's account"""
    try:
        # Get strategy data from request
        data = request.json
        strategy_name = data.get("name")
        description = data.get("description")
        estimated_savings = data.get("estimated_savings")
        
        if not strategy_name or not description:
            return jsonify({"success": False, "message": "Strategy name and description are required"}), 400
        
        # Get user's business profile for tax year
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        tax_year = profile.tax_year if profile else datetime.utcnow().year
        
        # Create new strategy
        new_strategy = TaxStrategy(
            user_id=current_user.id,
            strategy_name=strategy_name,
            description=description,
            estimated_savings=estimated_savings,
            tax_year=tax_year,
            tier="premium" if current_user.plan == "pro" else "basic"
        )
        
        db.session.add(new_strategy)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": "Strategy saved successfully",
            "strategy_id": new_strategy.id
        })
    
    except Exception as e:
        logger.error(f"Error saving strategy: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500

@automation_bp.route("/guided-troubleshooting")
@login_required
def guided_troubleshooting():
    """Interactive troubleshooting wizard"""
    return render_template("automation/guided_troubleshooting.html")

@automation_bp.route("/troubleshoot", methods=["POST"])
@login_required
def troubleshoot():
    """Get AI troubleshooting guidance"""
    try:
        # Get issue description from request
        data = request.json
        issue_description = data.get("issue_description")
        
        if not issue_description:
            return jsonify({"success": False, "message": "Issue description is required"}), 400
        
        # Get user's business profile
        profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
        
        # Convert enum to string if needed
        business_entity_type = None
        if profile and hasattr(profile.business_type, 'value'):
            business_entity_type = profile.business_type.value
        
        # Prepare troubleshooting prompt
        troubleshooting_prompt = f"I'm having an issue with the .fylr tax filing application: {issue_description}"
        
        if profile:
            troubleshooting_prompt += f"\n\nMy business is a {business_entity_type}."
        
        troubleshooting_prompt += "\n\nPlease provide step-by-step guidance to resolve this issue."
        
        # Get AI guidance
        guidance = get_openai_response("troubleshooter", troubleshooting_prompt, business_entity_type)
        
        if not guidance:
            return jsonify({"success": False, "message": "Failed to get troubleshooting guidance"}), 500
        
        return jsonify({
            "success": True,
            "guidance": guidance
        })
    
    except Exception as e:
        logger.error(f"Error getting troubleshooting guidance: {str(e)}")
        return jsonify({"success": False, "message": f"An error occurred: {str(e)}"}), 500
