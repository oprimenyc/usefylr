/* Mobile-specific JavaScript enhancements */

document.addEventListener('DOMContentLoaded', function() {
  // Fix for iOS input zoom
  const viewportMeta = document.querySelector('meta[name="viewport"]');
  if (viewportMeta && /iPhone|iPad|iPod/.test(navigator.userAgent)) {
    viewportMeta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
  }
  
  // Enhance touch feedback for all interactive elements
  const touchElements = document.querySelectorAll('.touch-feedback');
  touchElements.forEach(element => {
    element.addEventListener('touchstart', function() {
      this.classList.add('active-touch');
    });
    
    element.addEventListener('touchend', function() {
      this.classList.remove('active-touch');
    });
  });
  
  // Improve dropdown behavior on mobile
  const dropdownItems = document.querySelectorAll('.dropdown-item');
  dropdownItems.forEach(item => {
    item.addEventListener('click', function() {
      // Close the dropdown menu after item selection on mobile
      const bsCollapse = bootstrap.Collapse.getInstance(document.querySelector('.navbar-collapse'));
      if (bsCollapse && window.innerWidth < 992) {
        bsCollapse.hide();
      }
    });
  });
  
  // Add swipe gesture support for common actions
  let touchStartX = 0;
  let touchEndX = 0;
  
  document.addEventListener('touchstart', function(e) {
    touchStartX = e.changedTouches[0].screenX;
  }, false);
  
  document.addEventListener('touchend', function(e) {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipe();
  }, false);
  
  function handleSwipe() {
    const swipeThreshold = 100; // Minimum distance for swipe detection
    
    if (touchEndX - touchStartX > swipeThreshold) {
      // Right swipe - go back in form steps or navigation
      const backButton = document.querySelector('.btn-back');
      if (backButton) {
        backButton.click();
      }
    }
    
    if (touchStartX - touchEndX > swipeThreshold) {
      // Left swipe - go forward in form steps or navigation
      const nextButton = document.querySelector('.btn-next');
      if (nextButton) {
        nextButton.click();
      }
    }
  }
  
  // Improve form validation feedback on mobile
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    form.addEventListener('submit', function(event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
        
        // Scroll to the first invalid field
        const invalidField = form.querySelector(':invalid');
        if (invalidField) {
          invalidField.focus();
          invalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
      
      form.classList.add('was-validated');
    }, false);
  });
  
  // Enhance mobile file uploads
  const fileInputs = document.querySelectorAll('input[type="file"]');
  fileInputs.forEach(input => {
    input.addEventListener('change', function() {
      // Update file name display
      const fileNameDisplay = this.nextElementSibling;
      if (fileNameDisplay && this.files.length > 0) {
        fileNameDisplay.textContent = this.files[0].name;
      }
    });
  });
  
  // Fix for position:fixed elements when virtual keyboard is visible on mobile
  const fixedElements = document.querySelectorAll('.fixed-bottom, .fixed-top');
  const inputs = document.querySelectorAll('input:not([type="radio"]):not([type="checkbox"]), textarea');
  
  inputs.forEach(input => {
    input.addEventListener('focus', function() {
      // When input is focused and keyboard appears, change fixed elements to position:absolute
      if (/Android|iPhone|iPad|iPod/.test(navigator.userAgent)) {
        fixedElements.forEach(el => {
          el.style.position = 'absolute';
        });
      }
    });
    
    input.addEventListener('blur', function() {
      // When input loses focus and keyboard disappears, restore fixed positioning
      setTimeout(() => {
        fixedElements.forEach(el => {
          el.style.position = 'fixed';
        });
      }, 100);
    });
  });
  
  // Add pull-to-refresh functionality for dashboard and data pages
  let touchStartY = 0;
  let touchEndY = 0;
  
  const refreshablePages = document.querySelectorAll('.refreshable-page');
  refreshablePages.forEach(page => {
    page.addEventListener('touchstart', function(e) {
      touchStartY = e.changedTouches[0].screenY;
    }, false);
    
    page.addEventListener('touchend', function(e) {
      touchEndY = e.changedTouches[0].screenY;
      handlePullToRefresh(this);
    }, false);
  });
  
  function handlePullToRefresh(element) {
    const pullThreshold = 150; // Minimum distance for pull detection
    
    if (touchEndY - touchStartY > pullThreshold && window.scrollY === 0) {
      // User pulled down at the top of the page
      const refreshIndicator = document.createElement('div');
      refreshIndicator.className = 'refresh-indicator';
      refreshIndicator.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> Refreshing...';
      element.prepend(refreshIndicator);
      
      // Reload the page after a short delay
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
  }
  
  // Optimize table display on mobile
  const tables = document.querySelectorAll('.mobile-card-table');
  tables.forEach(table => {
    const headers = Array.from(table.querySelectorAll('thead th')).map(th => th.textContent.trim());
    
    const dataCells = table.querySelectorAll('tbody td');
    dataCells.forEach((cell, index) => {
      const headerIndex = index % headers.length;
      cell.setAttribute('data-label', headers[headerIndex]);
    });
  });
});
