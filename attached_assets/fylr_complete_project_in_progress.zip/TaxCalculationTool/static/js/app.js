/**
 * Enhanced Guided Tour for .fylr
 * High-quality implementation with theme consistency, feature flags, and responsive design
 */

document.addEventListener('DOMContentLoaded', () => {
  
  /* ---- Feature flags from backend (injected server-side or via JS) ---- */
  const features = {
    importEnabled: true,   // Stripe / PayPal import
    w2Enabled: true        // W-2 generator
  };
  
  /**
   * Build tour steps dynamically based on available features and current theme
   * @returns {Array} Array of tour step objects
   */
  function buildTourSteps() {
    const steps = [];
    
    // Dashboard (always present)
    const dashboardElement = document.querySelector('[data-guide="dashboard"]');
    if (dashboardElement) {
      steps.push({
        element: dashboardElement,
        title: 'Your Dashboard',
        intro: 'Welcome to your .fylr dashboard! Here you'll see all your tax tasks at a glance.',
        position: 'bottom'
      });
    }
    
    // Document upload
    const uploadElement = document.querySelector('[data-guide="upload"]');
    if (uploadElement) {
      steps.push({
        element: uploadElement,
        title: 'Document Upload',
        intro: 'Upload PDFs, images or CSVs here. AI will auto-tag and classify them.',
        position: 'right'
      });
    }
    
    // Stripe / PayPal import (conditional)
    if (features.importEnabled) {
      const importElement = document.querySelector('[data-guide="import"]');
      if (importElement) {
        steps.push({
          element: importElement,
          title: 'Transaction Import',
          intro: 'Connect Stripe or PayPal to import transactions for 1099 matching.',
          position: 'left'
        });
      }
    }
    
    // W-2 generator (conditional)
    if (features.w2Enabled) {
      const w2Element = document.querySelector('[data-guide="w2"]');
      if (w2Element) {
        steps.push({
          element: w2Element,
          title: 'W-2 Generator',
          intro: 'Need W-2s? Enter payroll data and generate employee forms here.',
          position: 'top'
        });
      }
    }
    
    // Filing summary
    const summaryElement = document.querySelector('[data-guide="summary"]');
    if (summaryElement) {
      steps.push({
        element: summaryElement,
        title: 'Filing Summary',
        intro: 'Review your filing summary and download IRS-ready forms when you're done.',
        position: 'bottom'
      });
    }
    
    return steps;
  }
  
  /**
   * Initialize and start the guided tour with premium styling
   */
  function startTour() {
    // Create IntroJS instance
    const intro = introJs();
    
    // Get current theme for styling
    const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
    
    // Set theme-aware options
    intro.setOptions({
      steps: buildTourSteps(),
      showProgress: true,
      showBullets: false,
      disableInteraction: true,
      scrollToElement: true,
      nextLabel: 'Next →',
      prevLabel: '← Back',
      doneLabel: 'Got it!',
      tooltipClass: `introjs-tooltip-${currentTheme}`,
      highlightClass: `introjs-highlight-${currentTheme}`
    });
    
    // Handle theme changes during tour
    document.addEventListener('themeChanged', () => {
      const updatedTheme = document.documentElement.getAttribute('data-theme') || 'light';
      const tooltips = document.querySelectorAll('.introjs-tooltip');
      
      tooltips.forEach(tooltip => {
        tooltip.classList.remove('introjs-tooltip-light', 'introjs-tooltip-dark');
        tooltip.classList.add(`introjs-tooltip-${updatedTheme}`);
      });
      
      const highlights = document.querySelectorAll('.introjs-helperLayer');
      highlights.forEach(highlight => {
        highlight.classList.remove('introjs-highlight-light', 'introjs-highlight-dark');
        highlight.classList.add(`introjs-highlight-${updatedTheme}`);
      });
    });
    
    // Start the tour
    intro.start();
    
    // Track tour completion
    intro.oncomplete(() => {
      console.log('Tour completed');
      localStorage.setItem('fylrTourShown', 'true');
    });
    
    // Track tour exit
    intro.onexit(() => {
      console.log('Tour exited');
      localStorage.setItem('fylrTourShown', 'true');
    });
  }
  
  /**
   * Add help button to the page if it doesn't exist
   */
  function addHelpButton() {
    if (!document.getElementById('replayTour')) {
      const helpButton = document.createElement('button');
      helpButton.id = 'replayTour';
      helpButton.className = 'help-btn';
      helpButton.innerHTML = '?';
      helpButton.setAttribute('aria-label', 'Start guided tour');
      helpButton.setAttribute('title', 'Take a tour');
      
      document.body.appendChild(helpButton);
    }
  }
  
  // Add help button to the page
  addHelpButton();
  
  // Auto-run once for first-time users
  const TOUR_FLAG = 'fylrTourShown';
  if (!localStorage.getItem(TOUR_FLAG)) {
    // Slight delay to ensure page is fully loaded
    setTimeout(() => {
      startTour();
    }, 1000);
  }
  
  // Replay tour on demand
  const replayButton = document.getElementById('replayTour');
  if (replayButton) {
    replayButton.addEventListener('click', startTour);
  }
});
