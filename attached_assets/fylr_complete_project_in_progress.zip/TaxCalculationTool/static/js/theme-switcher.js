/**
 * Theme Switcher for .fylr Application
 * 
 * This script handles theme switching between light and dark modes,
 * ensuring consistent application across the entire application.
 */

// Self-executing function to avoid polluting global namespace
(function() {
    // Theme constants
    const THEME_LIGHT = 'light';
    const THEME_DARK = 'dark';
    const STORAGE_KEY = 'fylr_theme_preference';
    
    // DOM elements
    let themeSwitchers;
    
    /**
     * Initialize theme functionality
     */
    function initTheme() {
        // Get theme switcher elements
        themeSwitchers = document.querySelectorAll('.theme-switch input[type="checkbox"]');
        
        // Set initial theme based on stored preference or system preference
        setInitialTheme();
        
        // Add event listeners to all theme switchers
        themeSwitchers.forEach(switcher => {
            switcher.addEventListener('change', handleThemeToggle);
        });
        
        // Listen for system theme changes
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.addEventListener('change', handleSystemThemeChange);
        }
        
        // Add theme class to body for immediate styling
        document.body.classList.add('theme-transition-ready');
    }
    
    /**
     * Set initial theme based on stored preference or system preference
     */
    function setInitialTheme() {
        // Check for stored preference
        const storedTheme = localStorage.getItem(STORAGE_KEY);
        
        if (storedTheme) {
            // Use stored preference
            setTheme(storedTheme);
        } else {
            // Use system preference
            const prefersDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            setTheme(prefersDarkMode ? THEME_DARK : THEME_LIGHT);
        }
        
        // Update all theme switchers to match current theme
        updateSwitchers();
    }
    
    /**
     * Handle theme toggle from any switcher
     */
    function handleThemeToggle(event) {
        const newTheme = event.target.checked ? THEME_DARK : THEME_LIGHT;
        setTheme(newTheme);
        
        // Sync all other switchers
        updateSwitchers();
    }
    
    /**
     * Handle system theme change
     */
    function handleSystemThemeChange(event) {
        // Only change theme if user hasn't set a preference
        if (!localStorage.getItem(STORAGE_KEY)) {
            const newTheme = event.matches ? THEME_DARK : THEME_LIGHT;
            setTheme(newTheme);
            updateSwitchers();
        }
    }
    
    /**
     * Set theme on document and store preference
     */
    function setTheme(theme) {
        // Set data-theme attribute on document element
        document.documentElement.setAttribute('data-theme', theme);
        
        // Store preference
        localStorage.setItem(STORAGE_KEY, theme);
        
        // Dispatch custom event for other components that might need to react
        document.dispatchEvent(new CustomEvent('themeChanged', { 
            detail: { theme: theme }
        }));
    }
    
    /**
     * Update all switchers to match current theme
     */
    function updateSwitchers() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        
        themeSwitchers.forEach(switcher => {
            switcher.checked = currentTheme === THEME_DARK;
        });
    }
    
    /**
     * Get current theme
     */
    function getCurrentTheme() {
        return document.documentElement.getAttribute('data-theme');
    }
    
    /**
     * Toggle current theme
     */
    function toggleTheme() {
        const currentTheme = getCurrentTheme();
        const newTheme = currentTheme === THEME_LIGHT ? THEME_DARK : THEME_LIGHT;
        setTheme(newTheme);
        updateSwitchers();
    }
    
    // Initialize theme when DOM is loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initTheme);
    } else {
        initTheme();
    }
    
    // Expose public methods
    window.ThemeSwitcher = {
        toggle: toggleTheme,
        setTheme: setTheme,
        getCurrentTheme: getCurrentTheme
    };
})();
