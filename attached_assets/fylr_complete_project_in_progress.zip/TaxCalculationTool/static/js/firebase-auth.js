/**
 * Firebase Authentication for .fylr
 * Handles Google Sign-In integration with the application
 */

// Firebase configuration - to be replaced with actual config from Firebase console
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get elements
const googleSignInButton = document.getElementById('google-signin');
const signOutButton = document.getElementById('sign-out');
const userDisplayName = document.getElementById('user-display-name');
const userEmail = document.getElementById('user-email');
const userPhoto = document.getElementById('user-photo');
const authStateMessage = document.getElementById('auth-state-message');

/**
 * Sign in with Google
 */
function signInWithGoogle() {
  // Show loading indicator
  if (authStateMessage) {
    authStateMessage.textContent = 'Signing in...';
    authStateMessage.classList.remove('d-none');
  }
  
  const provider = new firebase.auth.GoogleAuthProvider();
  // Add scopes if needed
  provider.addScope('profile');
  provider.addScope('email');
  
  // Sign in with redirect for better mobile experience
  firebase.auth().signInWithRedirect(provider)
    .catch((error) => {
      console.error('Error during sign in:', error);
      if (authStateMessage) {
        authStateMessage.textContent = `Sign in error: ${error.message}`;
        authStateMessage.classList.add('text-danger');
      }
    });
}

/**
 * Sign out the current user
 */
function signOut() {
  firebase.auth().signOut()
    .then(() => {
      console.log('User signed out');
      // Redirect to home or login page
      window.location.href = '/login';
    })
    .catch((error) => {
      console.error('Error signing out:', error);
    });
}

/**
 * Handle auth state changes
 */
function initAuth() {
  // Check for redirect result
  firebase.auth().getRedirectResult()
    .then((result) => {
      if (result.credential) {
        // This gives you a Google Access Token
        const token = result.credential.accessToken;
        console.log('Successfully signed in with Google');
        
        // Send the Firebase ID token to your backend
        return firebase.auth().currentUser.getIdToken(true);
      }
    })
    .then((idToken) => {
      if (idToken) {
        // Send token to your backend via HTTPS
        return sendTokenToBackend(idToken);
      }
    })
    .catch((error) => {
      console.error('Error getting redirect result:', error);
      if (authStateMessage) {
        authStateMessage.textContent = `Authentication error: ${error.message}`;
        authStateMessage.classList.add('text-danger');
      }
    });
  
  // Listen for auth state changes
  firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      // User is signed in
      console.log('User is signed in:', user.displayName);
      
      // Update UI
      updateUIForSignedInUser(user);
      
      // Get the ID token
      user.getIdToken(true)
        .then((idToken) => {
          // Send token to backend if not already done
          if (!sessionStorage.getItem('tokenSentToBackend')) {
            return sendTokenToBackend(idToken);
          }
        })
        .catch((error) => {
          console.error('Error getting ID token:', error);
        });
    } else {
      // User is signed out
      console.log('User is signed out');
      updateUIForSignedOutUser();
      
      // Clear session storage
      sessionStorage.removeItem('tokenSentToBackend');
    }
  });
}

/**
 * Send Firebase ID token to backend for verification and session creation
 */
function sendTokenToBackend(idToken) {
  return fetch('/auth/firebase/verify', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ idToken }),
  })
  .then((response) => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json();
  })
  .then((data) => {
    console.log('Token verification successful:', data);
    
    // Mark that token was sent to backend
    sessionStorage.setItem('tokenSentToBackend', 'true');
    
    // Redirect to dashboard or requested page
    if (data.redirect) {
      window.location.href = data.redirect;
    }
  })
  .catch((error) => {
    console.error('Error sending token to backend:', error);
    if (authStateMessage) {
      authStateMessage.textContent = 'Error verifying your login. Please try again.';
      authStateMessage.classList.add('text-danger');
    }
  });
}

/**
 * Update UI for signed in user
 */
function updateUIForSignedInUser(user) {
  if (userDisplayName) {
    userDisplayName.textContent = user.displayName || 'User';
  }
  
  if (userEmail) {
    userEmail.textContent = user.email;
  }
  
  if (userPhoto && user.photoURL) {
    userPhoto.src = user.photoURL;
    userPhoto.classList.remove('d-none');
  }
  
  if (googleSignInButton) {
    googleSignInButton.classList.add('d-none');
  }
  
  if (signOutButton) {
    signOutButton.classList.remove('d-none');
  }
  
  if (authStateMessage) {
    authStateMessage.textContent = 'You are signed in';
    authStateMessage.classList.remove('text-danger');
    authStateMessage.classList.add('text-success');
  }
  
  // Add signed-in class to body for CSS targeting
  document.body.classList.add('user-signed-in');
}

/**
 * Update UI for signed out user
 */
function updateUIForSignedOutUser() {
  if (userDisplayName) {
    userDisplayName.textContent = '';
  }
  
  if (userEmail) {
    userEmail.textContent = '';
  }
  
  if (userPhoto) {
    userPhoto.src = '';
    userPhoto.classList.add('d-none');
  }
  
  if (googleSignInButton) {
    googleSignInButton.classList.remove('d-none');
  }
  
  if (signOutButton) {
    signOutButton.classList.add('d-none');
  }
  
  if (authStateMessage) {
    authStateMessage.textContent = 'Please sign in to continue';
    authStateMessage.classList.remove('text-success', 'text-danger');
  }
  
  // Remove signed-in class from body
  document.body.classList.remove('user-signed-in');
}

// Add event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Initialize Firebase Auth
  initAuth();
  
  // Add click handlers
  if (googleSignInButton) {
    googleSignInButton.addEventListener('click', signInWithGoogle);
  }
  
  if (signOutButton) {
    signOutButton.addEventListener('click', signOut);
  }
});
