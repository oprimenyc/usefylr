/**
 * Enhanced Guided Tour for .fylr
 * High-quality implementation with theme consistency and responsive design
 */

// Configuration for different page types
const tourConfig = {
  // Dashboard tour configuration
  dashboard: [
    {
      element: '[data-guide="dashboard"]',
      title: 'Your Dashboard',
      intro: 'Welcome to your personalized dashboard. Here you can track your tax filing progress and access all features.',
      position: 'bottom'
    },
    {
      element: '[data-guide="upload"]',
      title: 'Document Upload',
      intro: 'Easily upload your tax documents here. Our AI will automatically extract and organize the relevant information.',
      position: 'right'
    },
    {
      element: '[data-guide="import"]',
      title: 'Import Transactions',
      intro: 'Import transactions directly from Stripe or PayPal to automatically generate 1099 forms for your contractors.',
      position: 'left'
    },
    {
      element: '[data-guide="w2"]',
      title: 'W-2 Generator',
      intro: 'Generate W-2 forms for your employees with our intuitive form builder and batch processing tools.',
      position: 'top'
    },
    {
      element: '[data-guide="summary"]',
      title: 'Tax Summary',
      intro: 'Review your complete tax situation at a glance, with AI-powered insights and recommendations.',
      position: 'bottom'
    }
  ],
  
  // Default tour for other pages
  default: [
    {
      title: 'Welcome to .fylr',
      intro: 'Let\'s take a quick tour of our AI-powered tax filing platform. Click "Next" to continue.',
    },
    {
      element: '.navbar-brand',
      title: 'Navigation',
      intro: 'Use the navigation menu to move around the platform. You can always return home by clicking our logo.',
      position: 'bottom'
    },
    {
      element: '#take-tour-button',
      title: 'Guided Tour',
      intro: 'You can restart this tour anytime by clicking this button or the help icon in the bottom right corner.',
      position: 'bottom'
    },
    {
      element: '#userDropdown',
      title: 'User Menu',
      intro: 'Access your profile settings, toggle dark mode, and log out from this menu.',
      position: 'left'
    }
  ]
};

/**
 * Initialize and start the guided tour
 * @param {string} tourType - Type of tour to show (dashboard, default, etc.)
 */
function initGuidedTour(tourType = 'default') {
  // Create IntroJS instance with custom settings
  const intro = introJs();
  
  // Set theme-aware options
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  
  // Configure the tour
  intro.setOptions({
    steps: tourConfig[tourType] || tourConfig.default,
    showProgress: true,
    showBullets: true,
    showStepNumbers: false,
    hideNext: false,
    hidePrev: false,
    nextLabel: 'Next →',
    prevLabel: '← Back',
    doneLabel: 'Finish Tour',
    tooltipClass: `introjs-tooltip-${currentTheme}`,
    highlightClass: `introjs-highlight-${currentTheme}`,
    exitOnOverlayClick: false,
    disableInteraction: false,
    scrollToElement: true,
    scrollPadding: 30
  });
  
  // Handle theme changes during tour
  document.addEventListener('themeChanged', () => {
    const updatedTheme = document.documentElement.getAttribute('data-theme') || 'light';
    const tooltips = document.querySelectorAll('.introjs-tooltip');
    
    tooltips.forEach(tooltip => {
      tooltip.classList.remove('introjs-tooltip-light', 'introjs-tooltip-dark');
      tooltip.classList.add(`introjs-tooltip-${updatedTheme}`);
    });
    
    const highlights = document.querySelectorAll('.introjs-helperLayer');
    highlights.forEach(highlight => {
      highlight.classList.remove('introjs-highlight-light', 'introjs-highlight-dark');
      highlight.classList.add(`introjs-highlight-${updatedTheme}`);
    });
  });
  
  // Start the tour
  intro.start();
  
  // Track tour completion
  intro.oncomplete(() => {
    console.log('Tour completed');
    localStorage.setItem('fylr_tour_completed', 'true');
    localStorage.setItem('fylr_tour_completed_date', new Date().toISOString());
  });
  
  // Track tour exit
  intro.onexit(() => {
    console.log('Tour exited');
    localStorage.setItem('fylr_tour_started', 'true');
  });
  
  // Track tour progress
  intro.onchange((targetElement) => {
    console.log('Tour step changed', targetElement);
    // You can add analytics tracking here
  });
  
  return intro;
}

/**
 * Determine which tour to show based on current page and elements
 */
function showGuidedTour() {
  // Detect current page type
  let tourType = 'default';
  
  // Check for dashboard elements
  if (document.querySelector('[data-guide="dashboard"]')) {
    tourType = 'dashboard';
  }
  
  // Initialize the appropriate tour
  initGuidedTour(tourType);
}

/**
 * Add help button to the page if it doesn't exist
 */
function addHelpButton() {
  if (!document.getElementById('replayTour')) {
    const helpButton = document.createElement('button');
    helpButton.id = 'replayTour';
    helpButton.className = 'help-btn';
    helpButton.innerHTML = '?';
    helpButton.setAttribute('aria-label', 'Start guided tour');
    helpButton.setAttribute('title', 'Take a tour');
    
    helpButton.addEventListener('click', () => {
      showGuidedTour();
    });
    
    document.body.appendChild(helpButton);
  }
}

/**
 * Check if user is a first-time visitor and show tour automatically
 */
function checkFirstTimeVisitor() {
  const tourCompleted = localStorage.getItem('fylr_tour_completed');
  const tourStarted = localStorage.getItem('fylr_tour_started');
  
  // If first visit or tour never completed, show tour automatically
  if (!tourStarted && !tourCompleted) {
    // Slight delay to ensure page is fully loaded
    setTimeout(() => {
      showGuidedTour();
    }, 1000);
  }
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
  // Add help button
  addHelpButton();
  
  // Check if first-time visitor
  checkFirstTimeVisitor();
  
  // Enable all tooltips
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
});
