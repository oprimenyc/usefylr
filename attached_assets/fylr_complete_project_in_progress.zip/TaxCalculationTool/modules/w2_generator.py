"""
W-2 Generator Module

This module provides functionality for generating W-2 forms from payroll data.
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.models import User, BusinessProfile, TaxForm, TaxFormType
from app.access_control import requires_access_level
import os
import json
import logging
from datetime import datetime
import tempfile
from fpdf2 import FPDF
import re

# Create blueprint
w2_generator_bp = Blueprint('w2_generator', __name__, url_prefix='/w2-generator')

# Create model for W-2 forms
class W2Form(db.Model):
    """Model for storing W-2 form data"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tax_form_id = db.Column(db.Integer, db.ForeignKey('tax_form.id'), nullable=False)
    employee_name = db.Column(db.String(128), nullable=False)
    employee_ssn = db.Column(db.String(11), nullable=False)
    employee_address = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    
    # Form data
    wages_box1 = db.Column(db.Float, nullable=False)  # Wages, tips, other compensation
    federal_tax_box2 = db.Column(db.Float, nullable=False)  # Federal income tax withheld
    ss_wages_box3 = db.Column(db.Float, nullable=False)  # Social security wages
    ss_tax_box4 = db.Column(db.Float, nullable=False)  # Social security tax withheld
    medicare_wages_box5 = db.Column(db.Float, nullable=False)  # Medicare wages and tips
    medicare_tax_box6 = db.Column(db.Float, nullable=False)  # Medicare tax withheld
    
    # State information
    state_code = db.Column(db.String(2))
    state_wages = db.Column(db.Float)
    state_tax = db.Column(db.Float)
    
    # Tax year
    tax_year = db.Column(db.Integer, default=datetime.utcnow().year - 1)  # Previous tax year by default
    
    # Relationship
    tax_form = db.relationship('TaxForm', backref='w2_forms')
    
    def __repr__(self):
        return f'<W2Form {self.employee_name} {self.tax_year}>'

@w2_generator_bp.route('/')
@login_required
def index():
    """Display the W-2 generator dashboard"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'w2_generator'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get existing W-2 forms
    w2_forms = W2Form.query.filter_by(user_id=current_user.id).all()
    
    # Get payroll data if available
    payroll_data = get_payroll_data(current_user.id)
    
    return render_template('w2_generator/index.html',
                          business_profile=business_profile,
                          w2_forms=w2_forms,
                          payroll_data=payroll_data)

@w2_generator_bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_w2():
    """Create a new W-2 form"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'w2_generator'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not business_profile:
        flash("Please complete your business profile first", "warning")
        return redirect(url_for('main.profile'))
    
    # Check for required business information
    if not business_profile.ein:
        flash("Your business EIN is required for W-2 forms. Please update your business profile.", "warning")
        return redirect(url_for('main.profile'))
    
    if not business_profile.business_address:
        flash("Your business address is required for W-2 forms. Please update your business profile.", "warning")
        return redirect(url_for('main.profile'))
    
    if request.method == 'POST':
        # Get form data
        employee_name = request.form.get('employee_name')
        employee_ssn = request.form.get('employee_ssn')
        employee_address = request.form.get('employee_address')
        wages_box1 = request.form.get('wages_box1', type=float)
        federal_tax_box2 = request.form.get('federal_tax_box2', type=float)
        ss_wages_box3 = request.form.get('ss_wages_box3', type=float)
        ss_tax_box4 = request.form.get('ss_tax_box4', type=float)
        medicare_wages_box5 = request.form.get('medicare_wages_box5', type=float)
        medicare_tax_box6 = request.form.get('medicare_tax_box6', type=float)
        state_code = request.form.get('state_code')
        state_wages = request.form.get('state_wages', type=float)
        state_tax = request.form.get('state_tax', type=float)
        tax_year = request.form.get('tax_year', type=int, default=datetime.now().year - 1)
        
        # Validate required fields
        if not all([employee_name, employee_ssn, employee_address, 
                   wages_box1 is not None, federal_tax_box2 is not None,
                   ss_wages_box3 is not None, ss_tax_box4 is not None,
                   medicare_wages_box5 is not None, medicare_tax_box6 is not None]):
            flash("Please fill in all required fields", "warning")
            return render_template('w2_generator/new.html',
                                  business_profile=business_profile,
                                  tax_year=tax_year)
        
        # Validate SSN format
        if not validate_ssn(employee_ssn):
            flash("Please enter a valid SSN in the format XXX-XX-XXXX", "warning")
            return render_template('w2_generator/new.html',
                                  business_profile=business_profile,
                                  tax_year=tax_year)
        
        try:
            # Create form data
            form_data = {
                'employer': {
                    'name': business_profile.business_name,
                    'ein': business_profile.ein,
                    'address': {
                        'street': business_profile.business_address,
                        'city': '',  # Would parse from address in real implementation
                        'state': '',
                        'zip': ''
                    }
                },
                'employee': {
                    'name': employee_name,
                    'ssn': employee_ssn,
                    'address': {
                        'street': employee_address,
                        'city': '',  # Would parse from address in real implementation
                        'state': '',
                        'zip': ''
                    }
                },
                'wages': {
                    'box1': wages_box1,
                    'box2': federal_tax_box2,
                    'box3': ss_wages_box3,
                    'box4': ss_tax_box4,
                    'box5': medicare_wages_box5,
                    'box6': medicare_tax_box6,
                    'state': {
                        'code': state_code,
                        'income': state_wages,
                        'withholding': state_tax
                    }
                },
                'year': str(tax_year)
            }
            
            # Create tax form record
            tax_form = TaxForm(
                user_id=current_user.id,
                form_type=TaxFormType.FORM_W2,
                tax_year=tax_year,
                status='draft',
                data=form_data
            )
            
            db.session.add(tax_form)
            db.session.flush()  # Get the ID without committing
            
            # Create W-2 form record
            w2_form = W2Form(
                user_id=current_user.id,
                tax_form_id=tax_form.id,
                employee_name=employee_name,
                employee_ssn=employee_ssn,
                employee_address=employee_address,
                wages_box1=wages_box1,
                federal_tax_box2=federal_tax_box2,
                ss_wages_box3=ss_wages_box3,
                ss_tax_box4=ss_tax_box4,
                medicare_wages_box5=medicare_wages_box5,
                medicare_tax_box6=medicare_tax_box6,
                state_code=state_code,
                state_wages=state_wages,
                state_tax=state_tax,
                tax_year=tax_year
            )
            
            db.session.add(w2_form)
            db.session.commit()
            
            flash(f"W-2 form for {employee_name} created successfully", "success")
            return redirect(url_for('w2_generator.view_w2', form_id=w2_form.id))
        
        except Exception as e:
            db.session.rollback()
            logging.error(f"Error creating W-2 form: {str(e)}")
            flash(f"Error creating W-2 form: {str(e)}", "danger")
    
    # GET request - show the form
    return render_template('w2_generator/new.html',
                          business_profile=business_profile,
                          tax_year=datetime.now().year - 1)

@w2_generator_bp.route('/view/<int:form_id>')
@login_required
def view_w2(form_id):
    """View a W-2 form"""
    # Get the W-2 form
    w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Get the tax form
    tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first_or_404()
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    return render_template('w2_generator/view.html',
                          w2_form=w2_form,
                          tax_form=tax_form,
                          business_profile=business_profile)

@w2_generator_bp.route('/edit/<int:form_id>', methods=['GET', 'POST'])
@login_required
def edit_w2(form_id):
    """Edit a W-2 form"""
    # Get the W-2 form
    w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Get the tax form
    tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first_or_404()
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if request.method == 'POST':
        # Get form data
        employee_name = request.form.get('employee_name')
        employee_ssn = request.form.get('employee_ssn')
        employee_address = request.form.get('employee_address')
        wages_box1 = request.form.get('wages_box1', type=float)
        federal_tax_box2 = request.form.get('federal_tax_box2', type=float)
        ss_wages_box3 = request.form.get('ss_wages_box3', type=float)
        ss_tax_box4 = request.form.get('ss_tax_box4', type=float)
        medicare_wages_box5 = request.form.get('medicare_wages_box5', type=float)
        medicare_tax_box6 = request.form.get('medicare_tax_box6', type=float)
        state_code = request.form.get('state_code')
        state_wages = request.form.get('state_wages', type=float)
        state_tax = request.form.get('state_tax', type=float)
        
        # Validate required fields
        if not all([employee_name, employee_ssn, employee_address, 
                   wages_box1 is not None, federal_tax_box2 is not None,
                   ss_wages_box3 is not None, ss_tax_box4 is not None,
                   medicare_wages_box5 is not None, medicare_tax_box6 is not None]):
            flash("Please fill in all required fields", "warning")
            return render_template('w2_generator/edit.html',
                                  w2_form=w2_form,
                                  business_profile=business_profile)
        
        # Validate SSN format
        if not validate_ssn(employee_ssn):
            flash("Please enter a valid SSN in the format XXX-XX-XXXX", "warning")
            return render_template('w2_generator/edit.html',
                                  w2_form=w2_form,
                                  business_profile=business_profile)
        
        try:
            # Update form data
            form_data = tax_form.data
            form_data['employee']['name'] = employee_name
            form_data['employee']['ssn'] = employee_ssn
            form_data['employee']['address']['street'] = employee_address
            form_data['wages']['box1'] = wages_box1
            form_data['wages']['box2'] = federal_tax_box2
            form_data['wages']['box3'] = ss_wages_box3
            form_data['wages']['box4'] = ss_tax_box4
            form_data['wages']['box5'] = medicare_wages_box5
            form_data['wages']['box6'] = medicare_tax_box6
            form_data['wages']['state']['code'] = state_code
            form_data['wages']['state']['income'] = state_wages
            form_data['wages']['state']['withholding'] = state_tax
            
            tax_form.data = form_data
            tax_form.updated_at = datetime.utcnow()
            
            # Update W-2 form record
            w2_form.employee_name = employee_name
            w2_form.employee_ssn = employee_ssn
            w2_form.employee_address = employee_address
            w2_form.wages_box1 = wages_box1
            w2_form.federal_tax_box2 = federal_tax_box2
            w2_form.ss_wages_box3 = ss_wages_box3
            w2_form.ss_tax_box4 = ss_tax_box4
            w2_form.medicare_wages_box5 = medicare_wages_box5
            w2_form.medicare_tax_box6 = medicare_tax_box6
            w2_form.state_code = state_code
            w2_form.state_wages = state_wages
            w2_form.state_tax = state_tax
            w2_form.updated_at = datetime.utcnow()
            
            db.session.commit()
            
            flash(f"W-2 form for {employee_name} updated successfully", "success")
            return redirect(url_for('w2_generator.view_w2', form_id=w2_form.id))
        
        except Exception as e:
            db.session.rollback()
            logging.error(f"Error updating W-2 form: {str(e)}")
            flash(f"Error updating W-2 form: {str(e)}", "danger")
    
    # GET request - show the form
    return render_template('w2_generator/edit.html',
                          w2_form=w2_form,
                          business_profile=business_profile)

@w2_generator_bp.route('/delete/<int:form_id>', methods=['POST'])
@login_required
def delete_w2(form_id):
    """Delete a W-2 form"""
    # Get the W-2 form
    w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Get the tax form
    tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first_or_404()
    
    try:
        # Delete the W-2 form and tax form
        db.session.delete(w2_form)
        db.session.delete(tax_form)
        db.session.commit()
        
        flash("W-2 form deleted successfully", "success")
        return redirect(url_for('w2_generator.index'))
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error deleting W-2 form: {str(e)}")
        flash(f"Error deleting W-2 form: {str(e)}", "danger")
        return redirect(url_for('w2_generator.view_w2', form_id=form_id))

@w2_generator_bp.route('/generate-pdf/<int:form_id>')
@login_required
def generate_pdf(form_id):
    """Generate a PDF for a W-2 form"""
    # Get the W-2 form
    w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Get the tax form
    tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first_or_404()
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    try:
        # Generate PDF
        pdf_path = generate_w2_pdf(w2_form, tax_form, business_profile)
        
        if pdf_path:
            # In a real implementation, this would return the file for download
            # For this prototype, we'll redirect to a success page
            flash("W-2 PDF generated successfully", "success")
            return redirect(url_for('w2_generator.view_w2', form_id=form_id))
        else:
            flash("Error generating W-2 PDF", "danger")
            return redirect(url_for('w2_generator.view_w2', form_id=form_id))
    
    except Exception as e:
        logging.error(f"Error generating W-2 PDF: {str(e)}")
        flash(f"Error generating W-2 PDF: {str(e)}", "danger")
        return redirect(url_for('w2_generator.view_w2', form_id=form_id))

@w2_generator_bp.route('/batch-generate')
@login_required
def batch_generate():
    """Show the batch generation page"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'w2_generator'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    # Get all W-2 forms
    w2_forms = W2Form.query.filter_by(user_id=current_user.id).all()
    
    # Get departments (would come from payroll data in a real implementation)
    departments = ['Sales', 'Marketing', 'Engineering', 'HR', 'Finance']
    
    # Get pay types (would come from payroll data in a real implementation)
    pay_types = ['Salary', 'Hourly', 'Commission', 'Bonus']
    
    return render_template('w2_generator/batch.html',
                          business_profile=business_profile,
                          w2_forms=w2_forms,
                          departments=departments,
                          pay_types=pay_types,
                          tax_year=datetime.now().year - 1)

@w2_generator_bp.route('/execute-batch', methods=['POST'])
@login_required
def execute_batch():
    """Execute batch generation of W-2 forms"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'w2_generator'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get filter parameters
    departments = request.form.getlist('departments')
    pay_types = request.form.getlist('pay_types')
    tax_year = request.form.get('tax_year', type=int, default=datetime.now().year - 1)
    
    # Get business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not business_profile:
        flash("Please complete your business profile first", "warning")
        return redirect(url_for('main.profile'))
    
    # Check for required business information
    if not business_profile.ein:
        flash("Your business EIN is required for W-2 forms. Please update your business profile.", "warning")
        return redirect(url_for('main.profile'))
    
    if not business_profile.business_address:
        flash("Your business address is required for W-2 forms. Please update your business profile.", "warning")
        return redirect(url_for('main.profile'))
    
    try:
        # Get payroll data
        payroll_data = get_payroll_data(current_user.id)
        
        if not payroll_data:
            flash("No payroll data found", "warning")
            return redirect(url_for('w2_generator.batch_generate'))
        
        # Filter payroll data based on departments and pay types
        filtered_data = []
        for entry in payroll_data:
            # In a real implementation, this would filter based on actual data
            # For this prototype, we'll include all entries
            filtered_data.append(entry)
        
        if not filtered_data:
            flash("No matching payroll data found with the selected filters", "warning")
            return redirect(url_for('w2_generator.batch_generate'))
        
        # Generate W-2 forms for each employee
        generated_forms = []
        errors = []
        
        for employee_data in filtered_data:
            # Check for required employee information
            if not employee_data.get('ssn'):
                errors.append(f"Missing SSN for {employee_data.get('name')}")
                continue
            
            if not employee_data.get('address'):
                errors.append(f"Missing address for {employee_data.get('name')}")
                continue
            
            # Create form data
            form_data = {
                'employer': {
                    'name': business_profile.business_name,
                    'ein': business_profile.ein,
                    'address': {
                        'street': business_profile.business_address,
                        'city': '',  # Would parse from address in real implementation
                        'state': '',
                        'zip': ''
                    }
                },
                'employee': {
                    'name': employee_data.get('name'),
                    'ssn': employee_data.get('ssn'),
                    'address': {
                        'street': employee_data.get('address'),
                        'city': '',  # Would parse from address in real implementation
                        'state': '',
                        'zip': ''
                    }
                },
                'wages': {
                    'box1': employee_data.get('wages', 0),
                    'box2': employee_data.get('federal_tax', 0),
                    'box3': employee_data.get('ss_wages', 0),
                    'box4': employee_data.get('ss_tax', 0),
                    'box5': employee_data.get('medicare_wages', 0),
                    'box6': employee_data.get('medicare_tax', 0),
                    'state': {
                        'code': employee_data.get('state_code', ''),
                        'income': employee_data.get('state_wages', 0),
                        'withholding': employee_data.get('state_tax', 0)
                    }
                },
                'year': str(tax_year)
            }
            
            # Create tax form record
            tax_form = TaxForm(
                user_id=current_user.id,
                form_type=TaxFormType.FORM_W2,
                tax_year=tax_year,
                status='draft',
                data=form_data
            )
            
            db.session.add(tax_form)
            db.session.flush()  # Get the ID without committing
            
            # Create W-2 form record
            w2_form = W2Form(
                user_id=current_user.id,
                tax_form_id=tax_form.id,
                employee_name=employee_data.get('name'),
                employee_ssn=employee_data.get('ssn'),
                employee_address=employee_data.get('address'),
                wages_box1=employee_data.get('wages', 0),
                federal_tax_box2=employee_data.get('federal_tax', 0),
                ss_wages_box3=employee_data.get('ss_wages', 0),
                ss_tax_box4=employee_data.get('ss_tax', 0),
                medicare_wages_box5=employee_data.get('medicare_wages', 0),
                medicare_tax_box6=employee_data.get('medicare_tax', 0),
                state_code=employee_data.get('state_code', ''),
                state_wages=employee_data.get('state_wages', 0),
                state_tax=employee_data.get('state_tax', 0),
                tax_year=tax_year
            )
            
            db.session.add(w2_form)
            generated_forms.append({
                'name': employee_data.get('name'),
                'form_id': w2_form.id
            })
        
        db.session.commit()
        
        if errors:
            for error in errors:
                flash(error, "warning")
        
        if generated_forms:
            flash(f"Successfully generated {len(generated_forms)} W-2 forms", "success")
        
        return render_template('w2_generator/batch_results.html',
                              generated_forms=generated_forms,
                              errors=errors)
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error generating batch W-2 forms: {str(e)}")
        flash(f"Error generating batch W-2 forms: {str(e)}", "danger")
        return redirect(url_for('w2_generator.batch_generate'))

@w2_generator_bp.route('/batch-pdf', methods=['POST'])
@login_required
def batch_pdf():
    """Generate PDFs for multiple W-2 forms"""
    # Get selected form IDs
    form_ids = request.form.getlist('form_ids', type=int)
    
    if not form_ids:
        flash("Please select at least one W-2 form", "warning")
        return redirect(url_for('w2_generator.index'))
    
    try:
        # Generate PDFs for each selected form
        generated_pdfs = []
        errors = []
        
        for form_id in form_ids:
            # Get the W-2 form
            w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first()
            
            if not w2_form:
                errors.append(f"Form ID {form_id} not found")
                continue
            
            # Get the tax form
            tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first()
            
            if not tax_form:
                errors.append(f"Tax form not found for W-2 form ID {form_id}")
                continue
            
            # Get business profile
            business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
            
            # Generate PDF
            pdf_path = generate_w2_pdf(w2_form, tax_form, business_profile)
            
            if pdf_path:
                generated_pdfs.append({
                    'name': w2_form.employee_name,
                    'path': pdf_path
                })
            else:
                errors.append(f"Error generating PDF for {w2_form.employee_name}")
        
        if errors:
            for error in errors:
                flash(error, "warning")
        
        if generated_pdfs:
            flash(f"Successfully generated {len(generated_pdfs)} W-2 PDFs", "success")
        
        # In a real implementation, this would provide download links or a zip file
        # For this prototype, we'll redirect back to the index
        return redirect(url_for('w2_generator.index'))
    
    except Exception as e:
        logging.error(f"Error generating batch W-2 PDFs: {str(e)}")
        flash(f"Error generating batch W-2 PDFs: {str(e)}", "danger")
        return redirect(url_for('w2_generator.index'))

@w2_generator_bp.route('/import-from-payroll')
@login_required
def import_from_payroll():
    """Import W-2 data from payroll records"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'w2_generator'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get payroll data
    payroll_data = get_payroll_data(current_user.id)
    
    if not payroll_data:
        flash("No payroll data found", "warning")
        return redirect(url_for('w2_generator.index'))
    
    # Group payroll data by employee
    employees = {}
    for entry in payroll_data:
        employee_name = entry.get('employee')
        if employee_name not in employees:
            employees[employee_name] = []
        
        employees[employee_name].append(entry)
    
    return render_template('w2_generator/import_payroll.html',
                          employees=employees)

@w2_generator_bp.route('/api/w2-data/<int:form_id>')
@login_required
def api_get_w2_data(form_id):
    """API endpoint to get W-2 form data"""
    # Get the W-2 form
    w2_form = W2Form.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Get the tax form
    tax_form = TaxForm.query.filter_by(id=w2_form.tax_form_id).first_or_404()
    
    # Return the data
    return jsonify(tax_form.data)

# Helper functions

def is_feature_enabled_for_business(user_id, feature_name):
    """Check if a feature is enabled for the user's business type"""
    # Get the user's business profile
    business_profile = BusinessProfile.query.filter_by(user_id=user_id).first()
    
    if not business_profile:
        return False
    
    # In a real implementation, this would check against the admin settings
    # For now, we'll assume it's enabled for all business types
    return True

def get_payroll_data(user_id):
    """Get payroll data for the user"""
    # In a real implementation, this would query the payroll database
    # For this prototype, we'll return sample data
    
    sample_data = [
        {
            'employee': 'James Carter',
            'ssn': '123-45-6789',
            'address': '456 Home St, Miami, FL 33101',
            'wages': 42000.00,
            'federal_tax': 5200.00,
            'ss_wages': 42000.00,
            'ss_tax': 2604.00,
            'medicare_wages': 42000.00,
            'medicare_tax': 609.00,
            'state_code': 'FL',
            'state_wages': 42000.00,
            'state_tax': 0.00,
            'department': 'Sales',
            'pay_type': 'Salary'
        },
        {
            'employee': 'Maria Rodriguez',
            'ssn': '234-56-7890',
            'address': '789 Oak Ave, Miami, FL 33101',
            'wages': 38000.00,
            'federal_tax': 4600.00,
            'ss_wages': 38000.00,
            'ss_tax': 2356.00,
            'medicare_wages': 38000.00,
            'medicare_tax': 551.00,
            'state_code': 'FL',
            'state_wages': 38000.00,
            'state_tax': 0.00,
            'department': 'Marketing',
            'pay_type': 'Salary'
        },
        {
            'employee': 'David Johnson',
            'ssn': '345-67-8901',
            'address': '123 Pine St, Miami, FL 33101',
            'wages': 55000.00,
            'federal_tax': 7200.00,
            'ss_wages': 55000.00,
            'ss_tax': 3410.00,
            'medicare_wages': 55000.00,
            'medicare_tax': 797.50,
            'state_code': 'FL',
            'state_wages': 55000.00,
            'state_tax': 0.00,
            'department': 'Engineering',
            'pay_type': 'Salary'
        }
    ]
    
    return sample_data

def validate_ssn(ssn):
    """Validate SSN format"""
    # Check if SSN matches the format XXX-XX-XXXX
    pattern = r'^\d{3}-\d{2}-\d{4}$'
    return bool(re.match(pattern, ssn))

def generate_w2_pdf(w2_form, tax_form, business_profile):
    """Generate a PDF for a W-2 form using FPDF2"""
    try:
        # Create PDF object
        pdf = FPDF()
        pdf.add_page()
        
        # Set font
        pdf.set_font("Arial", size=12)
        
        # Add title
        pdf.cell(200, 10, txt=f"Form W-2 Wage and Tax Statement {w2_form.tax_year}", ln=True, align='C')
        pdf.ln(10)
        
        # Add employer information
        pdf.set_font("Arial", 'B', size=10)
        pdf.cell(200, 10, txt="Employer Information", ln=True)
        pdf.set_font("Arial", size=10)
        pdf.cell(200, 10, txt=f"Name: {business_profile.business_name}", ln=True)
        pdf.cell(200, 10, txt=f"EIN: {business_profile.ein}", ln=True)
        pdf.cell(200, 10, txt=f"Address: {business_profile.business_address}", ln=True)
        pdf.ln(10)
        
        # Add employee information
        pdf.set_font("Arial", 'B', size=10)
        pdf.cell(200, 10, txt="Employee Information", ln=True)
        pdf.set_font("Arial", size=10)
        pdf.cell(200, 10, txt=f"Name: {w2_form.employee_name}", ln=True)
        pdf.cell(200, 10, txt=f"SSN: {w2_form.employee_ssn}", ln=True)
        pdf.cell(200, 10, txt=f"Address: {w2_form.employee_address}", ln=True)
        pdf.ln(10)
        
        # Add wage information
        pdf.set_font("Arial", 'B', size=10)
        pdf.cell(200, 10, txt="Wage Information", ln=True)
        pdf.set_font("Arial", size=10)
        pdf.cell(200, 10, txt=f"Box 1 - Wages, tips, other compensation: ${w2_form.wages_box1:.2f}", ln=True)
        pdf.cell(200, 10, txt=f"Box 2 - Federal income tax withheld: ${w2_form.federal_tax_box2:.2f}", ln=True)
        pdf.cell(200, 10, txt=f"Box 3 - Social security wages: ${w2_form.ss_wages_box3:.2f}", ln=True)
        pdf.cell(200, 10, txt=f"Box 4 - Social security tax withheld: ${w2_form.ss_tax_box4:.2f}", ln=True)
        pdf.cell(200, 10, txt=f"Box 5 - Medicare wages and tips: ${w2_form.medicare_wages_box5:.2f}", ln=True)
        pdf.cell(200, 10, txt=f"Box 6 - Medicare tax withheld: ${w2_form.medicare_tax_box6:.2f}", ln=True)
        pdf.ln(10)
        
        # Add state information
        if w2_form.state_code:
            pdf.set_font("Arial", 'B', size=10)
            pdf.cell(200, 10, txt="State Information", ln=True)
            pdf.set_font("Arial", size=10)
            pdf.cell(200, 10, txt=f"State: {w2_form.state_code}", ln=True)
            pdf.cell(200, 10, txt=f"State wages: ${w2_form.state_wages:.2f}", ln=True)
            pdf.cell(200, 10, txt=f"State income tax: ${w2_form.state_tax:.2f}", ln=True)
            pdf.ln(10)
        
        # Add disclaimer
        pdf.set_font("Arial", 'I', size=8)
        pdf.cell(200, 10, txt="This is an AI-generated draft. It is your responsibility to review and file correctly. No legal advice is provided.", ln=True)
        
        # Save the PDF to a temporary file
        pdf_dir = os.path.join(os.getcwd(), 'static', 'w2_forms')
        os.makedirs(pdf_dir, exist_ok=True)
        
        pdf_filename = f"w2_{w2_form.id}_{w2_form.tax_year}.pdf"
        pdf_path = os.path.join(pdf_dir, pdf_filename)
        
        pdf.output(pdf_path)
        
        return f"w2_forms/{pdf_filename}"
    
    except Exception as e:
        logging.error(f"Error generating W-2 PDF: {str(e)}")
        return None
