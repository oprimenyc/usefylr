"""
Stripe and PayPal Import Module

This module provides integration with Stripe and PayPal for importing
contractor transaction data and generating 1099 forms.
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash, session, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import User, BusinessProfile, TaxForm, TaxFormType
from app.access_control import requires_access_level
import os
import json
import requests
from datetime import datetime, timedelta
import logging
import time
import re

# Create blueprint
stripe_paypal_bp = Blueprint('stripe_paypal', __name__, url_prefix='/payment-imports')

# Create models for Stripe/PayPal imports
class StripePaypalImport(db.Model):
    """Model for storing Stripe/PayPal import sessions"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    source = db.Column(db.String(64), nullable=False)  # 'stripe' or 'paypal'
    account_id = db.Column(db.String(128))
    date_range_start = db.Column(db.Date, nullable=False)
    date_range_end = db.Column(db.Date, nullable=False)
    imported_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='success')
    transaction_count = db.Column(db.Integer, default=0)
    contractor_count = db.Column(db.Integer, default=0)
    
    # Import results and data
    results = db.Column(db.JSON)
    
    # Relationship to transactions
    transactions = db.relationship('ContractorTransaction', backref='import_session', lazy='dynamic')
    
    def __repr__(self):
        return f'<StripePaypalImport {self.source} {self.imported_at}>'

class ContractorTransaction(db.Model):
    """Model for storing contractor transactions from Stripe/PayPal"""
    id = db.Column(db.Integer, primary_key=True)
    import_id = db.Column(db.Integer, db.ForeignKey('stripe_paypal_import.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    transaction_id = db.Column(db.String(128), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    contractor_name = db.Column(db.String(128))
    contractor_email = db.Column(db.String(128))
    memo = db.Column(db.Text)
    tags = db.Column(db.JSON)  # JSON array of tags
    
    # 1099 classification
    is_1099_eligible = db.Column(db.Boolean, default=False)
    classification_method = db.Column(db.String(20), default='auto')  # 'auto' or 'manual'
    classification_reason = db.Column(db.String(128))
    
    # Additional contractor information (may be added later)
    contractor_address = db.Column(db.Text)
    contractor_tax_id = db.Column(db.String(20))  # SSN or EIN
    contractor_business_type = db.Column(db.String(20))  # individual, corporation, etc.
    
    def __repr__(self):
        return f'<ContractorTransaction {self.transaction_id} {self.amount}>'

# Configuration for Stripe/PayPal import
PAYMENT_PLATFORMS = {
    'stripe': {
        'name': 'Stripe',
        'icon': 'stripe_logo.png',
        'description': 'Import contractor payment data from your Stripe account.',
        'auth_type': 'api_key',
        'transaction_types': ['charge', 'payment_intent', 'payout']
    },
    'paypal': {
        'name': 'PayPal',
        'icon': 'paypal_logo.png',
        'description': 'Import contractor payment data from your PayPal account.',
        'auth_type': 'oauth2',
        'transaction_types': ['payment', 'payout', 'invoice_payment']
    }
}

# 1099 Classification Rules
DEFAULT_1099_RULES = {
    'threshold': 600,  # $600 threshold for 1099-NEC reporting
    'rules': [
        'payment_to_individual',
        'not_registered_corp',
        'annual_total >= 600',
        'description_keywords in ["Freelance", "Consulting", "Independent Contractor"]'
    ],
    'allow_manual_override': True
}

@stripe_paypal_bp.route('/')
@login_required
def index():
    """Display the Stripe/PayPal import dashboard"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get user's recent imports
    recent_imports = StripePaypalImport.query.filter_by(user_id=current_user.id).order_by(
        StripePaypalImport.imported_at.desc()
    ).limit(5).all()
    
    # Get 1099-eligible contractors
    eligible_contractors = get_1099_eligible_contractors(current_user.id)
    
    return render_template('stripe_paypal/index.html',
                          platforms=PAYMENT_PLATFORMS,
                          recent_imports=recent_imports,
                          eligible_contractors=eligible_contractors)

@stripe_paypal_bp.route('/import/<platform>')
@login_required
def import_page(platform):
    """Show the import page for Stripe or PayPal"""
    if platform not in PAYMENT_PLATFORMS:
        flash(f"Unsupported platform: {platform}", "danger")
        return redirect(url_for('stripe_paypal.index'))
    
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get current year for default date range
    current_year = datetime.now().year
    default_start_date = f"{current_year}-01-01"
    default_end_date = f"{current_year}-12-31"
    
    # Get transaction types for this platform
    transaction_types = PAYMENT_PLATFORMS[platform]['transaction_types']
    
    # Get 1099 classification rules
    classification_rules = get_classification_rules(current_user.id)
    
    return render_template('stripe_paypal/import.html',
                          platform=platform,
                          platform_info=PAYMENT_PLATFORMS[platform],
                          transaction_types=transaction_types,
                          default_start_date=default_start_date,
                          default_end_date=default_end_date,
                          classification_rules=classification_rules)

@stripe_paypal_bp.route('/import/<platform>/execute', methods=['POST'])
@login_required
def execute_import(platform):
    """Execute data import from Stripe or PayPal"""
    if platform not in PAYMENT_PLATFORMS:
        flash(f"Unsupported platform: {platform}", "danger")
        return redirect(url_for('stripe_paypal.index'))
    
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get import parameters
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    transaction_types = request.form.getlist('transaction_types')
    api_key = request.form.get('api_key')  # For Stripe
    
    if not start_date or not end_date:
        flash("Please specify a date range for the import", "warning")
        return redirect(url_for('stripe_paypal.import_page', platform=platform))
    
    if not transaction_types:
        flash("Please select at least one transaction type", "warning")
        return redirect(url_for('stripe_paypal.import_page', platform=platform))
    
    if platform == 'stripe' and not api_key:
        flash("Please provide your Stripe API key", "warning")
        return redirect(url_for('stripe_paypal.import_page', platform=platform))
    
    # Execute the import based on the platform
    if platform == 'stripe':
        import_result = import_stripe_data(current_user.id, api_key, start_date, end_date, transaction_types)
    elif platform == 'paypal':
        import_result = import_paypal_data(current_user.id, start_date, end_date, transaction_types)
    
    if import_result['success']:
        flash(f"Successfully imported {import_result['transaction_count']} transactions from {PAYMENT_PLATFORMS[platform]['name']}", "success")
        return redirect(url_for('stripe_paypal.review_import', import_id=import_result['import_id']))
    else:
        flash(f"Failed to import data from {PAYMENT_PLATFORMS[platform]['name']}: {import_result['message']}", "danger")
        return redirect(url_for('stripe_paypal.import_page', platform=platform))

@stripe_paypal_bp.route('/review/<int:import_id>')
@login_required
def review_import(import_id):
    """Review imported transactions and apply filters"""
    # Get the import session
    import_session = StripePaypalImport.query.filter_by(id=import_id, user_id=current_user.id).first_or_404()
    
    # Get transactions from this import
    transactions = ContractorTransaction.query.filter_by(import_id=import_id).all()
    
    # Get 1099 classification rules
    classification_rules = get_classification_rules(current_user.id)
    
    return render_template('stripe_paypal/review.html',
                          import_session=import_session,
                          transactions=transactions,
                          classification_rules=classification_rules)

@stripe_paypal_bp.route('/filter/<int:import_id>', methods=['POST'])
@login_required
def filter_transactions(import_id):
    """Apply filters to imported transactions"""
    # Get the import session
    import_session = StripePaypalImport.query.filter_by(id=import_id, user_id=current_user.id).first_or_404()
    
    # Get filter parameters
    min_amount = request.form.get('min_amount', type=float)
    max_amount = request.form.get('max_amount', type=float)
    start_date = request.form.get('start_date')
    end_date = request.form.get('end_date')
    keywords = request.form.get('keywords')
    
    # Build the query
    query = ContractorTransaction.query.filter_by(import_id=import_id)
    
    if min_amount is not None:
        query = query.filter(ContractorTransaction.amount >= min_amount)
    
    if max_amount is not None:
        query = query.filter(ContractorTransaction.amount <= max_amount)
    
    if start_date:
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        query = query.filter(ContractorTransaction.timestamp >= start_datetime)
    
    if end_date:
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        end_datetime = end_datetime.replace(hour=23, minute=59, second=59)
        query = query.filter(ContractorTransaction.timestamp <= end_datetime)
    
    if keywords:
        keyword_list = [k.strip() for k in keywords.split(',')]
        for keyword in keyword_list:
            query = query.filter(
                (ContractorTransaction.memo.ilike(f'%{keyword}%')) |
                (ContractorTransaction.contractor_name.ilike(f'%{keyword}%')) |
                (ContractorTransaction.contractor_email.ilike(f'%{keyword}%'))
            )
    
    # Execute the query
    transactions = query.all()
    
    return render_template('stripe_paypal/filtered_transactions.html',
                          import_session=import_session,
                          transactions=transactions)

@stripe_paypal_bp.route('/classify/<int:import_id>', methods=['POST'])
@login_required
def classify_transactions(import_id):
    """Classify transactions for 1099 reporting"""
    # Get the import session
    import_session = StripePaypalImport.query.filter_by(id=import_id, user_id=current_user.id).first_or_404()
    
    # Get classification parameters
    auto_classify = request.form.get('auto_classify') == 'true'
    threshold = request.form.get('threshold', type=float, default=600)
    
    if auto_classify:
        # Apply automatic classification based on rules
        classify_result = auto_classify_transactions(import_id, threshold)
        flash(f"Automatically classified {classify_result['classified_count']} transactions as 1099-eligible", "success")
    
    return redirect(url_for('stripe_paypal.review_import', import_id=import_id))

@stripe_paypal_bp.route('/update-classification/<int:transaction_id>', methods=['POST'])
@login_required
def update_classification(transaction_id):
    """Update the 1099 classification for a single transaction"""
    # Get the transaction
    transaction = ContractorTransaction.query.filter_by(id=transaction_id).first_or_404()
    
    # Verify ownership
    if transaction.user_id != current_user.id:
        flash("You don't have permission to modify this transaction", "danger")
        return redirect(url_for('stripe_paypal.index'))
    
    # Update classification
    is_eligible = request.form.get('is_1099_eligible') == 'true'
    reason = request.form.get('reason', 'Manual classification')
    
    transaction.is_1099_eligible = is_eligible
    transaction.classification_method = 'manual'
    transaction.classification_reason = reason
    
    db.session.commit()
    
    flash("Transaction classification updated", "success")
    return redirect(url_for('stripe_paypal.review_import', import_id=transaction.import_id))

@stripe_paypal_bp.route('/contractors')
@login_required
def view_contractors():
    """View all contractors from imported transactions"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get all contractors from transactions
    contractors = get_all_contractors(current_user.id)
    
    return render_template('stripe_paypal/contractors.html',
                          contractors=contractors)

@stripe_paypal_bp.route('/generate-1099/<contractor_email>')
@login_required
def generate_1099(contractor_email):
    """Generate 1099 form for a specific contractor"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get contractor information
    contractor = get_contractor_by_email(current_user.id, contractor_email)
    
    if not contractor:
        flash(f"Contractor not found: {contractor_email}", "danger")
        return redirect(url_for('stripe_paypal.view_contractors'))
    
    # Check if we have all required information
    if not contractor.get('tax_id'):
        flash(f"Missing tax ID (SSN/EIN) for {contractor['name']}. Please update contractor information.", "warning")
        return redirect(url_for('stripe_paypal.edit_contractor', email=contractor_email))
    
    if not contractor.get('address'):
        flash(f"Missing address for {contractor['name']}. Please update contractor information.", "warning")
        return redirect(url_for('stripe_paypal.edit_contractor', email=contractor_email))
    
    # Generate the 1099 form
    form_result = generate_1099_form(current_user.id, contractor_email)
    
    if form_result['success']:
        flash(f"Successfully generated 1099 form for {contractor['name']}", "success")
        return redirect(url_for('stripe_paypal.view_1099', form_id=form_result['form_id']))
    else:
        flash(f"Failed to generate 1099 form: {form_result['message']}", "danger")
        return redirect(url_for('stripe_paypal.view_contractors'))

@stripe_paypal_bp.route('/edit-contractor/<email>', methods=['GET', 'POST'])
@login_required
def edit_contractor(email):
    """Edit contractor information"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get contractor information
    contractor = get_contractor_by_email(current_user.id, email)
    
    if not contractor:
        flash(f"Contractor not found: {email}", "danger")
        return redirect(url_for('stripe_paypal.view_contractors'))
    
    if request.method == 'POST':
        # Update contractor information
        name = request.form.get('name')
        tax_id = request.form.get('tax_id')
        address = request.form.get('address')
        business_type = request.form.get('business_type')
        
        # Update all transactions for this contractor
        update_result = update_contractor_info(
            current_user.id, email, name, tax_id, address, business_type
        )
        
        if update_result['success']:
            flash(f"Successfully updated information for {name}", "success")
            return redirect(url_for('stripe_paypal.view_contractors'))
        else:
            flash(f"Failed to update contractor information: {update_result['message']}", "danger")
    
    return render_template('stripe_paypal/edit_contractor.html',
                          contractor=contractor)

@stripe_paypal_bp.route('/view-1099/<int:form_id>')
@login_required
def view_1099(form_id):
    """View a generated 1099 form"""
    # Get the form
    form = TaxForm.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Verify it's a 1099 form
    if form.form_type != TaxFormType.FORM_1099NEC:
        flash("Invalid form type", "danger")
        return redirect(url_for('stripe_paypal.view_contractors'))
    
    return render_template('stripe_paypal/view_1099.html',
                          form=form)

@stripe_paypal_bp.route('/download-1099/<int:form_id>')
@login_required
def download_1099(form_id):
    """Download a generated 1099 form as PDF"""
    # Get the form
    form = TaxForm.query.filter_by(id=form_id, user_id=current_user.id).first_or_404()
    
    # Verify it's a 1099 form
    if form.form_type != TaxFormType.FORM_1099NEC:
        flash("Invalid form type", "danger")
        return redirect(url_for('stripe_paypal.view_contractors'))
    
    # Generate PDF
    pdf_result = generate_1099_pdf(form_id)
    
    if pdf_result['success']:
        return redirect(url_for('static', filename=pdf_result['pdf_path']))
    else:
        flash(f"Failed to generate PDF: {pdf_result['message']}", "danger")
        return redirect(url_for('stripe_paypal.view_1099', form_id=form_id))

@stripe_paypal_bp.route('/batch-generate-1099')
@login_required
def batch_generate_1099():
    """Generate 1099 forms for all eligible contractors"""
    # Check if feature is enabled for the user's business type
    if not is_feature_enabled_for_business(current_user.id, 'stripe_paypal_import'):
        flash("This feature is not available for your business type or plan.", "warning")
        return redirect(url_for('main.dashboard'))
    
    # Get all eligible contractors
    eligible_contractors = get_1099_eligible_contractors(current_user.id)
    
    if not eligible_contractors:
        flash("No eligible contractors found for 1099 generation", "warning")
        return redirect(url_for('stripe_paypal.view_contractors'))
    
    # Generate 1099 forms for each eligible contractor
    generated_forms = []
    errors = []
    
    for contractor in eligible_contractors:
        # Check if we have all required information
        if not contractor.get('tax_id'):
            errors.append(f"Missing tax ID for {contractor['name']}")
            continue
        
        if not contractor.get('address'):
            errors.append(f"Missing address for {contractor['name']}")
            continue
        
        # Generate the 1099 form
        form_result = generate_1099_form(current_user.id, contractor['email'])
        
        if form_result['success']:
            generated_forms.append({
                'name': contractor['name'],
                'form_id': form_result['form_id']
            })
        else:
            errors.append(f"Failed to generate 1099 for {contractor['name']}: {form_result['message']}")
    
    if errors:
        for error in errors:
            flash(error, "warning")
    
    if generated_forms:
        flash(f"Successfully generated {len(generated_forms)} 1099 forms", "success")
    
    return render_template('stripe_paypal/batch_results.html',
                          generated_forms=generated_forms,
                          errors=errors)

# Helper functions

def is_feature_enabled_for_business(user_id, feature_name):
    """Check if a feature is enabled for the user's business type"""
    # Get the user's business profile
    business_profile = BusinessProfile.query.filter_by(user_id=user_id).first()
    
    if not business_profile:
        return False
    
    # In a real implementation, this would check against the admin settings
    # For now, we'll assume it's enabled for all business types
    return True

def get_classification_rules(user_id):
    """Get 1099 classification rules for the user"""
    # In a real implementation, this would get custom rules from the database
    # For now, we'll return the default rules
    return DEFAULT_1099_RULES

def import_stripe_data(user_id, api_key, start_date, end_date, transaction_types):
    """Import transaction data from Stripe"""
    try:
        # Parse dates
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        
        # In a real implementation, this would make API calls to Stripe
        # For this prototype, we'll simulate the import with sample data
        
        # Create import record
        import_session = StripePaypalImport(
            user_id=user_id,
            source='stripe',
            account_id='acct_sample',
            date_range_start=start_datetime,
            date_range_end=end_datetime,
            status='success'
        )
        
        db.session.add(import_session)
        db.session.flush()  # Get the ID without committing
        
        # Sample transactions
        sample_transactions = [
            {
                'transaction_id': 'txn_sample1',
                'timestamp': datetime(2025, 3, 5, 12, 34, 0),
                'amount': 750.00,
                'currency': 'USD',
                'contractor_name': 'Maria Jackson',
                'contractor_email': 'maria@example.com',
                'memo': 'January freelance design work',
                'tags': ['design', 'freelance']
            },
            {
                'transaction_id': 'txn_sample2',
                'timestamp': datetime(2025, 4, 10, 14, 15, 0),
                'amount': 1200.00,
                'currency': 'USD',
                'contractor_name': 'Devon Lee',
                'contractor_email': 'devon@example.com',
                'memo': 'Monthly retainer payment',
                'tags': ['consulting']
            },
            {
                'transaction_id': 'txn_sample3',
                'timestamp': datetime(2025, 2, 15, 9, 30, 0),
                'amount': 500.00,
                'currency': 'USD',
                'contractor_name': 'Alex Chen',
                'contractor_email': 'alex@example.com',
                'memo': 'Website development',
                'tags': ['development', 'web']
            }
        ]
        
        # Add transactions to database
        for tx_data in sample_transactions:
            transaction = ContractorTransaction(
                import_id=import_session.id,
                user_id=user_id,
                transaction_id=tx_data['transaction_id'],
                timestamp=tx_data['timestamp'],
                amount=tx_data['amount'],
                currency=tx_data['currency'],
                contractor_name=tx_data['contractor_name'],
                contractor_email=tx_data['contractor_email'],
                memo=tx_data['memo'],
                tags=tx_data['tags']
            )
            db.session.add(transaction)
        
        # Update import record with counts
        import_session.transaction_count = len(sample_transactions)
        import_session.contractor_count = len(set(tx['contractor_email'] for tx in sample_transactions))
        
        db.session.commit()
        
        return {
            'success': True,
            'import_id': import_session.id,
            'transaction_count': len(sample_transactions)
        }
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error importing Stripe data: {str(e)}")
        return {
            'success': False,
            'message': str(e)
        }

def import_paypal_data(user_id, start_date, end_date, transaction_types):
    """Import transaction data from PayPal"""
    try:
        # Parse dates
        start_datetime = datetime.strptime(start_date, '%Y-%m-%d')
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d')
        
        # In a real implementation, this would make API calls to PayPal
        # For this prototype, we'll simulate the import with sample data
        
        # Create import record
        import_session = StripePaypalImport(
            user_id=user_id,
            source='paypal',
            account_id='paypal_sample',
            date_range_start=start_datetime,
            date_range_end=end_datetime,
            status='success'
        )
        
        db.session.add(import_session)
        db.session.flush()  # Get the ID without committing
        
        # Sample transactions
        sample_transactions = [
            {
                'transaction_id': 'pp_sample1',
                'timestamp': datetime(2025, 1, 15, 10, 0, 0),
                'amount': 850.00,
                'currency': 'USD',
                'contractor_name': 'Sarah Johnson',
                'contractor_email': 'sarah@example.com',
                'memo': 'Content writing services',
                'tags': ['writing', 'content']
            },
            {
                'transaction_id': 'pp_sample2',
                'timestamp': datetime(2025, 2, 20, 15, 30, 0),
                'amount': 1500.00,
                'currency': 'USD',
                'contractor_name': 'Michael Brown',
                'contractor_email': 'michael@example.com',
                'memo': 'Marketing consultation',
                'tags': ['marketing', 'consulting']
            },
            {
                'transaction_id': 'pp_sample3',
                'timestamp': datetime(2025, 3, 10, 11, 45, 0),
                'amount': 650.00,
                'currency': 'USD',
                'contractor_name': 'Emma Wilson',
                'contractor_email': 'emma@example.com',
                'memo': 'Graphic design for brochure',
                'tags': ['design', 'graphics']
            }
        ]
        
        # Add transactions to database
        for tx_data in sample_transactions:
            transaction = ContractorTransaction(
                import_id=import_session.id,
                user_id=user_id,
                transaction_id=tx_data['transaction_id'],
                timestamp=tx_data['timestamp'],
                amount=tx_data['amount'],
                currency=tx_data['currency'],
                contractor_name=tx_data['contractor_name'],
                contractor_email=tx_data['contractor_email'],
                memo=tx_data['memo'],
                tags=tx_data['tags']
            )
            db.session.add(transaction)
        
        # Update import record with counts
        import_session.transaction_count = len(sample_transactions)
        import_session.contractor_count = len(set(tx['contractor_email'] for tx in sample_transactions))
        
        db.session.commit()
        
        return {
            'success': True,
            'import_id': import_session.id,
            'transaction_count': len(sample_transactions)
        }
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error importing PayPal data: {str(e)}")
        return {
            'success': False,
            'message': str(e)
        }

def auto_classify_transactions(import_id, threshold=600):
    """Automatically classify transactions for 1099 reporting"""
    try:
        # Get all transactions from this import
        transactions = ContractorTransaction.query.filter_by(import_id=import_id).all()
        
        # Group transactions by contractor
        contractor_totals = {}
        for tx in transactions:
            if tx.contractor_email not in contractor_totals:
                contractor_totals[tx.contractor_email] = {
                    'name': tx.contractor_name,
                    'total': 0,
                    'transactions': []
                }
            
            contractor_totals[tx.contractor_email]['total'] += tx.amount
            contractor_totals[tx.contractor_email]['transactions'].append(tx)
        
        # Apply classification rules
        classified_count = 0
        for email, data in contractor_totals.items():
            # Check if total payments exceed threshold
            if data['total'] >= threshold:
                # Check for keywords in transaction memos
                has_keywords = False
                for tx in data['transactions']:
                    keywords = ['freelance', 'consulting', 'contractor', 'independent']
                    memo_lower = tx.memo.lower() if tx.memo else ''
                    
                    for keyword in keywords:
                        if keyword in memo_lower:
                            has_keywords = True
                            break
                    
                    if has_keywords:
                        break
                
                # Classify all transactions for this contractor
                for tx in data['transactions']:
                    tx.is_1099_eligible = True
                    tx.classification_method = 'auto'
                    
                    if has_keywords:
                        tx.classification_reason = f"Annual total >= ${threshold} and keywords detected"
                    else:
                        tx.classification_reason = f"Annual total >= ${threshold}"
                    
                    classified_count += 1
        
        db.session.commit()
        
        return {
            'success': True,
            'classified_count': classified_count
        }
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error classifying transactions: {str(e)}")
        return {
            'success': False,
            'message': str(e),
            'classified_count': 0
        }

def get_all_contractors(user_id):
    """Get all contractors from imported transactions"""
    try:
        # Query all transactions for this user
        transactions = ContractorTransaction.query.filter_by(user_id=user_id).all()
        
        # Group by contractor email
        contractors = {}
        for tx in transactions:
            if tx.contractor_email not in contractors:
                contractors[tx.contractor_email] = {
                    'name': tx.contractor_name,
                    'email': tx.contractor_email,
                    'total_paid': 0,
                    'transaction_count': 0,
                    'last_payment_date': None,
                    'tax_id': tx.contractor_tax_id,
                    'address': tx.contractor_address,
                    'business_type': tx.contractor_business_type
                }
            
            contractors[tx.contractor_email]['total_paid'] += tx.amount
            contractors[tx.contractor_email]['transaction_count'] += 1
            
            if (not contractors[tx.contractor_email]['last_payment_date'] or 
                tx.timestamp > contractors[tx.contractor_email]['last_payment_date']):
                contractors[tx.contractor_email]['last_payment_date'] = tx.timestamp
        
        # Convert to list and sort by total paid (descending)
        contractor_list = list(contractors.values())
        contractor_list.sort(key=lambda x: x['total_paid'], reverse=True)
        
        return contractor_list
    
    except Exception as e:
        logging.error(f"Error getting contractors: {str(e)}")
        return []

def get_1099_eligible_contractors(user_id):
    """Get contractors eligible for 1099 reporting"""
    try:
        # Get all contractors
        all_contractors = get_all_contractors(user_id)
        
        # Get classification threshold
        rules = get_classification_rules(user_id)
        threshold = rules.get('threshold', 600)
        
        # Filter eligible contractors
        eligible_contractors = [c for c in all_contractors if c['total_paid'] >= threshold]
        
        return eligible_contractors
    
    except Exception as e:
        logging.error(f"Error getting eligible contractors: {str(e)}")
        return []

def get_contractor_by_email(user_id, email):
    """Get contractor information by email"""
    try:
        # Get all contractors
        all_contractors = get_all_contractors(user_id)
        
        # Find the contractor with matching email
        for contractor in all_contractors:
            if contractor['email'] == email:
                return contractor
        
        return None
    
    except Exception as e:
        logging.error(f"Error getting contractor by email: {str(e)}")
        return None

def update_contractor_info(user_id, email, name, tax_id, address, business_type):
    """Update information for a contractor"""
    try:
        # Get all transactions for this contractor
        transactions = ContractorTransaction.query.filter_by(
            user_id=user_id,
            contractor_email=email
        ).all()
        
        if not transactions:
            return {
                'success': False,
                'message': f"No transactions found for {email}"
            }
        
        # Update all transactions
        for tx in transactions:
            if name:
                tx.contractor_name = name
            
            if tax_id:
                tx.contractor_tax_id = tax_id
            
            if address:
                tx.contractor_address = address
            
            if business_type:
                tx.contractor_business_type = business_type
        
        db.session.commit()
        
        return {
            'success': True,
            'updated_count': len(transactions)
        }
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error updating contractor info: {str(e)}")
        return {
            'success': False,
            'message': str(e)
        }

def generate_1099_form(user_id, contractor_email):
    """Generate a 1099-NEC form for a contractor"""
    try:
        # Get contractor information
        contractor = get_contractor_by_email(user_id, contractor_email)
        
        if not contractor:
            return {
                'success': False,
                'message': f"Contractor not found: {contractor_email}"
            }
        
        # Get business profile
        business_profile = BusinessProfile.query.filter_by(user_id=user_id).first()
        
        if not business_profile:
            return {
                'success': False,
                'message': "Business profile not found"
            }
        
        # Create form data
        form_data = {
            'payer': {
                'name': business_profile.business_name,
                'ein': business_profile.ein,
                'address': business_profile.business_address
            },
            'recipient': {
                'name': contractor['name'],
                'tax_id': contractor['tax_id'],
                'address': contractor['address']
            },
            'payments': {
                'nonemployee_compensation': contractor['total_paid']
            },
            'tax_year': datetime.now().year - 1  # Previous tax year
        }
        
        # Create tax form record
        tax_form = TaxForm(
            user_id=user_id,
            form_type=TaxFormType.FORM_1099NEC,
            tax_year=form_data['tax_year'],
            status='draft',
            data=form_data
        )
        
        db.session.add(tax_form)
        db.session.commit()
        
        return {
            'success': True,
            'form_id': tax_form.id
        }
    
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error generating 1099 form: {str(e)}")
        return {
            'success': False,
            'message': str(e)
        }

def generate_1099_pdf(form_id):
    """Generate a PDF for a 1099-NEC form"""
    try:
        # Get the form
        form = TaxForm.query.filter_by(id=form_id).first()
        
        if not form:
            return {
                'success': False,
                'message': "Form not found"
            }
        
        # Verify it's a 1099 form
        if form.form_type != TaxFormType.FORM_1099NEC:
            return {
                'success': False,
                'message': "Invalid form type"
            }
        
        # In a real implementation, this would generate a PDF file
        # For this prototype, we'll assume it's successful
        
        pdf_path = f"1099_forms/1099_NEC_{form_id}.pdf"
        
        return {
            'success': True,
            'pdf_path': pdf_path
        }
    
    except Exception as e:
        logging.error(f"Error generating 1099 PDF: {str(e)}")
        return {
            'success': False,
            'message': str(e)
        }
