"""
Missing Data Prompts Module

This module provides utilities for detecting and prompting users about missing
required data for tax forms and other critical operations.
"""

from flask import flash, redirect, url_for, render_template
from app.models import User, BusinessProfile, TaxForm
import re
import logging

class DataValidator:
    """Utility class for validating tax-related data"""
    
    @staticmethod
    def validate_ein(ein):
        """
        Validate Employer Identification Number (EIN) format
        Format: XX-XXXXXXX (9 digits with hyphen after first 2 digits)
        """
        if not ein:
            return False
        
        # Remove any spaces
        ein = ein.replace(' ', '')
        
        # Check pattern XX-XXXXXXX
        pattern = r'^\d{2}-\d{7}$'
        return bool(re.match(pattern, ein))
    
    @staticmethod
    def validate_ssn(ssn):
        """
        Validate Social Security Number (SSN) format
        Format: XXX-XX-XXXX (9 digits with hyphens)
        """
        if not ssn:
            return False
        
        # Remove any spaces
        ssn = ssn.replace(' ', '')
        
        # Check pattern XXX-XX-XXXX
        pattern = r'^\d{3}-\d{2}-\d{4}$'
        return bool(re.match(pattern, ssn))
    
    @staticmethod
    def validate_address(address):
        """
        Validate that address contains minimum required information
        """
        if not address:
            return False
        
        # Check minimum length (basic validation)
        return len(address.strip()) >= 10
    
    @staticmethod
    def validate_wage_data(wages):
        """
        Validate wage data is present and valid
        """
        if wages is None:
            return False
        
        try:
            # Convert to float and check if it's a valid number
            wage_value = float(wages)
            return wage_value >= 0
        except (ValueError, TypeError):
            return False

class MissingDataDetector:
    """Utility class for detecting missing required data"""
    
    @staticmethod
    def check_business_profile(user_id):
        """
        Check if business profile has all required information
        Returns a dictionary of missing fields
        """
        missing = {}
        
        # Get business profile
        profile = BusinessProfile.query.filter_by(user_id=user_id).first()
        
        if not profile:
            missing['business_profile'] = "Complete business profile"
            return missing
        
        # Check required fields
        if not profile.business_name:
            missing['business_name'] = "Business name"
        
        if not profile.ein or not DataValidator.validate_ein(profile.ein):
            missing['ein'] = "Valid EIN (XX-XXXXXXX format)"
        
        if not profile.business_address or not DataValidator.validate_address(profile.business_address):
            missing['business_address'] = "Complete business address"
        
        return missing
    
    @staticmethod
    def check_contractor_data(contractor):
        """
        Check if contractor data has all required information for 1099 forms
        Returns a dictionary of missing fields
        """
        missing = {}
        
        # Check required fields
        if not contractor.get('name'):
            missing['name'] = "Contractor name"
        
        if not contractor.get('tax_id') or not (
            DataValidator.validate_ein(contractor.get('tax_id')) or 
            DataValidator.validate_ssn(contractor.get('tax_id'))
        ):
            missing['tax_id'] = "Valid Tax ID (SSN or EIN)"
        
        if not contractor.get('address') or not DataValidator.validate_address(contractor.get('address')):
            missing['address'] = "Complete mailing address"
        
        return missing
    
    @staticmethod
    def check_employee_data(employee):
        """
        Check if employee data has all required information for W-2 forms
        Returns a dictionary of missing fields
        """
        missing = {}
        
        # Check required fields
        if not employee.get('name'):
            missing['name'] = "Employee name"
        
        if not employee.get('ssn') or not DataValidator.validate_ssn(employee.get('ssn')):
            missing['ssn'] = "Valid SSN (XXX-XX-XXXX format)"
        
        if not employee.get('address') or not DataValidator.validate_address(employee.get('address')):
            missing['address'] = "Complete mailing address"
        
        # Check wage data
        if not DataValidator.validate_wage_data(employee.get('wages')):
            missing['wages'] = "Valid wage amount"
        
        if not DataValidator.validate_wage_data(employee.get('federal_tax')):
            missing['federal_tax'] = "Federal tax withholding amount"
        
        return missing

class DataPromptGenerator:
    """Utility class for generating user prompts for missing data"""
    
    @staticmethod
    def generate_business_profile_prompt(missing_fields):
        """
        Generate prompt for missing business profile data
        """
        if not missing_fields:
            return None
        
        message = "Your business profile is missing required information for tax forms:"
        
        for field, description in missing_fields.items():
            message += f"\n• {description}"
        
        message += "\n\nPlease update your business profile before continuing."
        
        return {
            'title': "Missing Business Information",
            'message': message,
            'action_url': url_for('main.profile'),
            'action_text': "Update Business Profile"
        }
    
    @staticmethod
    def generate_contractor_prompt(missing_fields, contractor_name, contractor_email):
        """
        Generate prompt for missing contractor data
        """
        if not missing_fields:
            return None
        
        message = f"Contractor '{contractor_name}' is missing required information for 1099 forms:"
        
        for field, description in missing_fields.items():
            message += f"\n• {description}"
        
        message += "\n\nPlease update the contractor information before generating 1099 forms."
        
        return {
            'title': "Missing Contractor Information",
            'message': message,
            'action_url': url_for('stripe_paypal.edit_contractor', email=contractor_email),
            'action_text': "Update Contractor"
        }
    
    @staticmethod
    def generate_employee_prompt(missing_fields, employee_name, form_id=None):
        """
        Generate prompt for missing employee data
        """
        if not missing_fields:
            return None
        
        message = f"Employee '{employee_name}' is missing required information for W-2 forms:"
        
        for field, description in missing_fields.items():
            message += f"\n• {description}"
        
        message += "\n\nPlease update the employee information before generating W-2 forms."
        
        action_url = url_for('w2_generator.edit_w2', form_id=form_id) if form_id else url_for('w2_generator.index')
        
        return {
            'title': "Missing Employee Information",
            'message': message,
            'action_url': action_url,
            'action_text': "Update Employee"
        }

def check_business_profile_for_tax_forms(user_id):
    """
    Check if business profile has all required information for tax forms
    Returns True if all required data is present, False otherwise
    """
    missing_fields = MissingDataDetector.check_business_profile(user_id)
    
    if missing_fields:
        prompt = DataPromptGenerator.generate_business_profile_prompt(missing_fields)
        flash(prompt['message'], "warning")
        return False
    
    return True

def check_contractor_for_1099(user_id, contractor_email):
    """
    Check if contractor has all required information for 1099 forms
    Returns True if all required data is present, False otherwise
    """
    from modules.stripe_paypal_import import get_contractor_by_email
    
    # Get contractor data
    contractor = get_contractor_by_email(user_id, contractor_email)
    
    if not contractor:
        flash(f"Contractor not found: {contractor_email}", "danger")
        return False
    
    missing_fields = MissingDataDetector.check_contractor_data(contractor)
    
    if missing_fields:
        prompt = DataPromptGenerator.generate_contractor_prompt(
            missing_fields, contractor['name'], contractor_email
        )
        flash(prompt['message'], "warning")
        return False
    
    return True

def check_employee_for_w2(employee_data, form_id=None):
    """
    Check if employee has all required information for W-2 forms
    Returns True if all required data is present, False otherwise
    """
    missing_fields = MissingDataDetector.check_employee_data(employee_data)
    
    if missing_fields:
        prompt = DataPromptGenerator.generate_employee_prompt(
            missing_fields, employee_data.get('name', 'Unknown'), form_id
        )
        flash(prompt['message'], "warning")
        return False
    
    return True

def generate_missing_data_notes(missing_fields, data_type):
    """
    Generate HTML notes for missing data fields
    """
    if not missing_fields:
        return ""
    
    notes = f'<div class="missing-data-notes alert alert-warning">'
    notes += f'<h5>Missing {data_type} Information</h5>'
    notes += '<ul>'
    
    for field, description in missing_fields.items():
        notes += f'<li>{description}</li>'
    
    notes += '</ul>'
    notes += '</div>'
    
    return notes
