"""
Admin Panel Module

This module provides admin functionality for managing application settings,
feature toggles, and user permissions.
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import User, BusinessProfile, BusinessType
from app.access_control import requires_access_level
import os
import json
import logging
from datetime import datetime

# Create blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Create model for feature toggles
class FeatureToggle(db.Model):
    """Model for storing feature toggle settings"""
    id = db.Column(db.Integer, primary_key=True)
    feature_name = db.Column(db.String(64), nullable=False, unique=True)
    is_enabled_global = db.Column(db.Boolean, default=False)
    business_type_settings = db.Column(db.JSON)  # JSON object with business type as key and boolean as value
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<FeatureToggle {self.feature_name}>'

# Default feature configuration
DEFAULT_FEATURES = {
    'stripe_paypal_import': {
        'name': 'Stripe/PayPal Import',
        'description': 'Import contractor payment data from Stripe and PayPal for 1099 generation',
        'is_enabled_global': True,
        'business_type_settings': {
            'sole_proprietor': True,
            'llc': True,
            's_corp': True,
            'c_corp': True
        }
    },
    'w2_generator': {
        'name': 'W-2 Generator',
        'description': 'Generate W-2 forms for employees from payroll data',
        'is_enabled_global': True,
        'business_type_settings': {
            'sole_proprietor': False,  # Sole proprietors typically don't have employees with W-2s
            'llc': True,
            's_corp': True,
            'c_corp': True
        }
    },
    'webhook_support': {
        'name': 'Webhook Support',
        'description': 'Support for Stripe and PayPal webhooks for real-time transaction updates',
        'is_enabled_global': False,  # Disabled by default as it's a future feature
        'business_type_settings': {
            'sole_proprietor': True,
            'llc': True,
            's_corp': True,
            'c_corp': True
        }
    }
}

# Role-based access control configuration
RBAC_ROLES = {
    'admin': ['full_access'],
    'staff': ['view', 'import'],
    'client_user': ['view_own_data']
}

@admin_bp.route('/')
@login_required
@requires_access_level('admin')
def index():
    """Admin dashboard"""
    # Get all feature toggles
    feature_toggles = FeatureToggle.query.all()
    
    # If no toggles exist, initialize with defaults
    if not feature_toggles:
        initialize_feature_toggles()
        feature_toggles = FeatureToggle.query.all()
    
    # Get user counts by business type
    business_type_counts = db.session.query(
        BusinessProfile.business_type, 
        db.func.count(BusinessProfile.id)
    ).group_by(BusinessProfile.business_type).all()
    
    # Convert to dictionary for easier access
    business_counts = {str(bt[0]): bt[1] for bt in business_type_counts}
    
    return render_template('admin/index.html',
                          feature_toggles=feature_toggles,
                          business_counts=business_counts,
                          rbac_roles=RBAC_ROLES)

@admin_bp.route('/features')
@login_required
@requires_access_level('admin')
def features():
    """Feature toggle management"""
    # Get all feature toggles
    feature_toggles = FeatureToggle.query.all()
    
    # If no toggles exist, initialize with defaults
    if not feature_toggles:
        initialize_feature_toggles()
        feature_toggles = FeatureToggle.query.all()
    
    # Get all business types
    business_types = [bt.value for bt in BusinessType]
    
    return render_template('admin/features.html',
                          feature_toggles=feature_toggles,
                          business_types=business_types,
                          default_features=DEFAULT_FEATURES)

@admin_bp.route('/update-feature', methods=['POST'])
@login_required
@requires_access_level('admin')
def update_feature():
    """Update feature toggle settings"""
    feature_name = request.form.get('feature_name')
    is_enabled_global = request.form.get('is_enabled_global') == 'true'
    
    # Get business type settings
    business_type_settings = {}
    for bt in [bt.value for bt in BusinessType]:
        business_type_settings[bt] = request.form.get(f'business_type_{bt}') == 'true'
    
    try:
        # Get the feature toggle
        feature = FeatureToggle.query.filter_by(feature_name=feature_name).first()
        
        if not feature:
            # Create new feature toggle
            feature = FeatureToggle(
                feature_name=feature_name,
                is_enabled_global=is_enabled_global,
                business_type_settings=business_type_settings
            )
            db.session.add(feature)
        else:
            # Update existing feature toggle
            feature.is_enabled_global = is_enabled_global
            feature.business_type_settings = business_type_settings
            feature.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        flash(f"Feature '{feature_name}' updated successfully", "success")
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error updating feature toggle: {str(e)}")
        flash(f"Error updating feature toggle: {str(e)}", "danger")
    
    return redirect(url_for('admin.features'))

@admin_bp.route('/reset-features', methods=['POST'])
@login_required
@requires_access_level('admin')
def reset_features():
    """Reset feature toggles to default settings"""
    try:
        # Delete all existing feature toggles
        FeatureToggle.query.delete()
        
        # Initialize with defaults
        initialize_feature_toggles()
        
        db.session.commit()
        
        flash("Feature toggles reset to default settings", "success")
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error resetting feature toggles: {str(e)}")
        flash(f"Error resetting feature toggles: {str(e)}", "danger")
    
    return redirect(url_for('admin.features'))

@admin_bp.route('/users')
@login_required
@requires_access_level('admin')
def users():
    """User management"""
    # Get all users
    users = User.query.all()
    
    return render_template('admin/users.html',
                          users=users,
                          rbac_roles=RBAC_ROLES)

@admin_bp.route('/update-user-role', methods=['POST'])
@login_required
@requires_access_level('admin')
def update_user_role():
    """Update user role"""
    user_id = request.form.get('user_id', type=int)
    role = request.form.get('role')
    
    if not user_id or not role:
        flash("Missing required parameters", "danger")
        return redirect(url_for('admin.users'))
    
    if role not in RBAC_ROLES:
        flash(f"Invalid role: {role}", "danger")
        return redirect(url_for('admin.users'))
    
    try:
        # Get the user
        user = User.query.get(user_id)
        
        if not user:
            flash(f"User not found: {user_id}", "danger")
            return redirect(url_for('admin.users'))
        
        # Update user role
        user.role = role
        db.session.commit()
        
        flash(f"Role for {user.username} updated to {role}", "success")
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error updating user role: {str(e)}")
        flash(f"Error updating user role: {str(e)}", "danger")
    
    return redirect(url_for('admin.users'))

@admin_bp.route('/webhooks')
@login_required
@requires_access_level('admin')
def webhooks():
    """Webhook management"""
    # Check if webhook feature is enabled
    webhook_feature = FeatureToggle.query.filter_by(feature_name='webhook_support').first()
    
    if not webhook_feature or not webhook_feature.is_enabled_global:
        flash("Webhook support is not enabled. Please enable it in the Features section.", "warning")
        return redirect(url_for('admin.features'))
    
    # Get webhook configuration
    webhook_config = {
        'stripe_events': [
            'payment_intent.succeeded',
            'charge.succeeded',
            'payout.paid'
        ],
        'paypal_events': [
            'PAYMENT.SALE.COMPLETED',
            'PAYMENT.CAPTURE.COMPLETED'
        ],
        'internal_events': [
            'threshold_1099_hit'
        ]
    }
    
    return render_template('admin/webhooks.html',
                          webhook_config=webhook_config)

@admin_bp.route('/test-webhook', methods=['POST'])
@login_required
@requires_access_level('admin')
def test_webhook():
    """Test webhook functionality"""
    webhook_type = request.form.get('webhook_type')
    event_type = request.form.get('event_type')
    
    if not webhook_type or not event_type:
        flash("Missing required parameters", "danger")
        return redirect(url_for('admin.webhooks'))
    
    try:
        # In a real implementation, this would simulate a webhook event
        # For this prototype, we'll just show a success message
        
        flash(f"Test webhook for {webhook_type} event {event_type} triggered successfully", "success")
    except Exception as e:
        logging.error(f"Error testing webhook: {str(e)}")
        flash(f"Error testing webhook: {str(e)}", "danger")
    
    return redirect(url_for('admin.webhooks'))

@admin_bp.route('/api/feature-status')
@login_required
def api_feature_status():
    """API endpoint to check if a feature is enabled for the current user"""
    feature_name = request.args.get('feature')
    
    if not feature_name:
        return jsonify({'error': 'Missing feature parameter'}), 400
    
    # Check if feature is enabled for the user's business type
    is_enabled = is_feature_enabled_for_business(current_user.id, feature_name)
    
    return jsonify({
        'feature': feature_name,
        'is_enabled': is_enabled
    })

@admin_bp.route('/api/business-type-detection')
@login_required
def api_business_type_detection():
    """API endpoint to detect business type for the current user"""
    # Get the user's business profile
    business_profile = BusinessProfile.query.filter_by(user_id=current_user.id).first()
    
    if not business_profile:
        return jsonify({
            'business_type': None,
            'features_enabled': []
        })
    
    # Get business type
    business_type = business_profile.business_type.value if hasattr(business_profile.business_type, 'value') else str(business_profile.business_type)
    
    # Get enabled features for this business type
    enabled_features = []
    for feature in FeatureToggle.query.all():
        if is_feature_enabled(feature, business_type):
            enabled_features.append(feature.feature_name)
    
    return jsonify({
        'business_type': business_type,
        'features_enabled': enabled_features
    })

# Helper functions

def initialize_feature_toggles():
    """Initialize feature toggles with default settings"""
    for feature_name, config in DEFAULT_FEATURES.items():
        feature = FeatureToggle(
            feature_name=feature_name,
            is_enabled_global=config['is_enabled_global'],
            business_type_settings=config['business_type_settings']
        )
        db.session.add(feature)
    
    db.session.commit()

def is_feature_enabled_for_business(user_id, feature_name):
    """Check if a feature is enabled for the user's business type"""
    # Get the user's business profile
    business_profile = BusinessProfile.query.filter_by(user_id=user_id).first()
    
    if not business_profile:
        return False
    
    # Get business type
    business_type = business_profile.business_type.value if hasattr(business_profile.business_type, 'value') else str(business_profile.business_type)
    
    # Get feature toggle
    feature = FeatureToggle.query.filter_by(feature_name=feature_name).first()
    
    if not feature:
        # If feature toggle doesn't exist, check default configuration
        if feature_name in DEFAULT_FEATURES:
            return (DEFAULT_FEATURES[feature_name]['is_enabled_global'] and 
                    DEFAULT_FEATURES[feature_name]['business_type_settings'].get(business_type, False))
        return False
    
    return is_feature_enabled(feature, business_type)

def is_feature_enabled(feature, business_type):
    """Check if a feature is enabled for a specific business type"""
    # First check global toggle
    if not feature.is_enabled_global:
        return False
    
    # Then check business type specific setting
    return feature.business_type_settings.get(business_type, False)
