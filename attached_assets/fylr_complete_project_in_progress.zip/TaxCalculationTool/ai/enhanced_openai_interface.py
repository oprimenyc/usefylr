import os
import json
import logging
from openai import OpenAI

# Get OpenAI API key from environment
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

# Load enhanced prompts
try:
    with open(os.path.join(os.path.dirname(__file__), 'enhanced_prompts.json'), 'r') as f:
        PROMPTS = json.load(f)
except (FileNotFoundError, json.JSONDecodeError) as e:
    logging.error(f"Error loading enhanced prompts: {str(e)}")
    # Fallback to original prompts if enhanced prompts can't be loaded
    try:
        with open(os.path.join(os.path.dirname(__file__), 'prompts.json'), 'r') as f:
            PROMPTS = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logging.error(f"Error loading fallback prompts: {str(e)}")
        PROMPTS = {}

def get_entity_specific_prompt(prompt_type, business_entity_type):
    """
    Get entity-specific prompt components based on business entity type
    
    Args:
        prompt_type: The type of prompt (e.g., 'tax_form_assistant')
        business_entity_type: The business entity type (e.g., 'sole_proprietor', 'llc', 's_corp', 'c_corp')
    
    Returns:
        dict: Entity-specific prompt components
    """
    if prompt_type not in PROMPTS:
        logging.error(f"Unknown prompt type: {prompt_type}")
        return {}
    
    prompt_config = PROMPTS[prompt_type]
    
    # Check if this prompt type has entity-specific configurations
    if "entity_specific" not in prompt_config:
        return {}
    
    # Normalize business entity type
    normalized_entity = business_entity_type.lower().replace(" ", "_").replace("-", "_")
    
    # Map common variations to standard types
    entity_map = {
        "sole_prop": "sole_proprietor",
        "sole_proprietorship": "sole_proprietor",
        "single_member_llc": "llc",
        "multi_member_llc": "llc",
        "s_corporation": "s_corp",
        "c_corporation": "c_corp"
    }
    
    if normalized_entity in entity_map:
        normalized_entity = entity_map[normalized_entity]
    
    # Get entity-specific components if available
    if normalized_entity in prompt_config["entity_specific"]:
        return prompt_config["entity_specific"][normalized_entity]
    
    # Default to empty if no match
    return {}

def get_openai_response(prompt_type, user_message_params, business_entity_type=None, model="gpt-4o", json_response=False):
    """
    Get a response from OpenAI's API using enhanced prompts
    
    Args:
        prompt_type: The type of prompt to use (e.g., 'tax_form_assistant')
        user_message_params: Dict of parameters to fill in the user message template
        business_entity_type: The business entity type for entity-specific prompts
        model: The model to use (default is gpt-4o)
        json_response: Whether to request a JSON response
    
    Returns:
        The response text or parsed JSON object
    """
    if not OPENAI_API_KEY:
        logging.error("OPENAI_API_KEY is not set")
        return None
    
    if prompt_type not in PROMPTS:
        logging.error(f"Unknown prompt type: {prompt_type}")
        return None
    
    try:
        prompt_config = PROMPTS[prompt_type]
        system_message = prompt_config["system"]
        user_template = prompt_config["user_template"]
        
        # Add entity-specific context if available
        if business_entity_type:
            entity_specific = get_entity_specific_prompt(prompt_type, business_entity_type)
            if entity_specific and "system_suffix" in entity_specific:
                system_message = f"{system_message} {entity_specific['system_suffix']}"
        
        # Fill in the user message template
        if isinstance(user_message_params, dict):
            # Add business_entity_type to params if not already present
            if business_entity_type and "business_entity_type" not in user_message_params:
                user_message_params["business_entity_type"] = business_entity_type
                
            # Format the user message with provided parameters
            try:
                user_message = user_template.format(**user_message_params)
            except KeyError as e:
                logging.error(f"Missing parameter in user message template: {str(e)}")
                # Use a partial format with available parameters
                for key, value in user_message_params.items():
                    user_template = user_template.replace("{" + key + "}", value)
                user_message = user_template
        else:
            # If not a dict, use the provided message directly
            user_message = user_message_params
        
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message}
        ]
        
        kwargs = {
            "model": model,
            "messages": messages,
            "max_tokens": 1500  # Increased token limit for more detailed responses
        }
        
        if json_response:
            kwargs["response_format"] = {"type": "json_object"}
        
        response = openai.chat.completions.create(**kwargs)
        
        response_text = response.choices[0].message.content
        
        if json_response:
            try:
                return json.loads(response_text)
            except json.JSONDecodeError:
                logging.error(f"Failed to parse JSON response: {response_text}")
                return None
        
        return response_text
    except Exception as e:
        logging.error(f"OpenAI API error: {str(e)}")
        return None

def handle_error_cases(prompt_type, error_type, params=None):
    """
    Generate appropriate error handling responses based on prompt configuration
    
    Args:
        prompt_type: The type of prompt (e.g., 'tax_form_assistant')
        error_type: The type of error (e.g., 'insufficient_info')
        params: Parameters to fill in the error message template
    
    Returns:
        Error handling message or None if not configured
    """
    if prompt_type not in PROMPTS:
        return None
    
    prompt_config = PROMPTS[prompt_type]
    
    # Check if this prompt type has error handling configurations
    if "error_handling" not in prompt_config:
        return None
    
    error_handling = prompt_config["error_handling"]
    
    if error_type not in error_handling:
        return None
    
    error_template = error_handling[error_type]
    
    # Fill in the error message template if params provided
    if params:
        try:
            return error_template.format(**params)
        except KeyError:
            return error_template
    
    return error_template

def analyze_image(base64_image, business_entity_type=None):
    """
    Analyze an image using OpenAI's Vision capabilities with enhanced context
    
    Args:
        base64_image: The base64-encoded image data
        business_entity_type: The business entity type for context-aware analysis
    
    Returns:
        The analysis text
    """
    try:
        # Create a context-aware system message based on business entity type
        system_message = "Analyze this tax document and extract key information such as form type, tax year, and key figures."
        
        if business_entity_type:
            entity_context = {
                "sole_proprietor": "Focus on Schedule C, 1040, and self-employment tax forms.",
                "llc": "Consider both entity-level and owner-level tax implications.",
                "s_corp": "Focus on Form 1120-S, K-1s, and shareholder-specific information.",
                "c_corp": "Focus on Form 1120 and corporate tax information."
            }
            
            normalized_entity = business_entity_type.lower().replace(" ", "_").replace("-", "_")
            if normalized_entity in entity_context:
                system_message += f" {entity_context[normalized_entity]}"
        
        system_message += " Provide a brief summary of what the document is for and how it relates to the business's tax situation."
        
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": system_message
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Please analyze this tax document and extract the key information."
                        },
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
                        }
                    ]
                }
            ],
            max_tokens=800
        )
        
        return response.choices[0].message.content
    except Exception as e:
        logging.error(f"OpenAI Vision API error: {str(e)}")
        return None

def get_form_specific_guidance(form_type, field_name=None):
    """
    Get form-specific guidance for tax forms
    
    Args:
        form_type: The type of tax form (e.g., 'schedule_c', 'form_1120s')
        field_name: Optional specific field name to get guidance for
    
    Returns:
        dict or string: Form guidance information
    """
    # Normalize form type
    normalized_form = form_type.lower().replace(" ", "_").replace("-", "").replace("form_", "")
    
    # Map common variations to standard types
    form_map = {
        "1040schedulec": "schedule_c",
        "schedulec": "schedule_c",
        "1065": "form_1065",
        "1120s": "form_1120s",
        "1120": "form_1120"
    }
    
    if normalized_form in form_map:
        normalized_form = form_map[normalized_form]
    
    # Check if we have form-specific guidance
    if "tax_form_assistant" in PROMPTS and "form_specific" in PROMPTS["tax_form_assistant"]:
        form_specific = PROMPTS["tax_form_assistant"]["form_specific"]
        
        if normalized_form in form_specific:
            form_guidance = form_specific[normalized_form]
            
            # If a specific field is requested
            if field_name and "common_fields" in form_guidance:
                normalized_field = field_name.lower().replace(" ", "_")
                if normalized_field in form_guidance["common_fields"]:
                    return form_guidance["common_fields"][normalized_field]
            
            return form_guidance
    
    return None

def get_industry_specific_guidance(prompt_type, industry):
    """
    Get industry-specific guidance for a prompt type
    
    Args:
        prompt_type: The type of prompt (e.g., 'audit_risk_analyzer')
        industry: The industry type (e.g., 'retail', 'professional_services')
    
    Returns:
        dict: Industry-specific guidance
    """
    if prompt_type not in PROMPTS:
        return None
    
    prompt_config = PROMPTS[prompt_type]
    
    # Check if this prompt type has industry-specific configurations
    if "industry_specific" not in prompt_config:
        return None
    
    # Normalize industry
    normalized_industry = industry.lower().replace(" ", "_").replace("-", "_")
    
    # Map common variations to standard types
    industry_map = {
        "retail_store": "retail",
        "ecommerce": "retail",
        "law": "professional_services",
        "accounting": "professional_services",
        "consulting": "professional_services",
        "real_estate_investment": "real_estate",
        "property_management": "real_estate",
        "software": "technology",
        "saas": "technology",
        "restaurant": "food_service",
        "cafe": "food_service"
    }
    
    if normalized_industry in industry_map:
        normalized_industry = industry_map[normalized_industry]
    
    # Get industry-specific components if available
    if normalized_industry in prompt_config["industry_specific"]:
        return prompt_config["industry_specific"][normalized_industry]
    
    # Default to None if no match
    return None
